import { WebSocketServer, WebSocket } from 'ws';
import { Server as HttpServer } from 'http';
import { WebSocketEventType, WebSocketMessage } from '../types/index.ts';

interface ClientConnection {
  ws: WebSocket;
  userId?: string;
  role?: 'CUSTOMER' | 'DRIVER' | 'ADMIN';
  subscribedRideIds: Set<string>;
}

export class SocketManager {
  private static instance: SocketManager;
  private wss: WebSocketServer | null = null;
  private clients: Map<WebSocket, ClientConnection> = new Map();

  private constructor() {}

  public static getInstance(): SocketManager {
    if (!SocketManager.instance) {
      SocketManager.instance = new SocketManager();
    }
    return SocketManager.instance;
  }

  public initialize(server: HttpServer) {
    this.wss = new WebSocketServer({ server, path: '/ws' });

    this.wss.on('connection', (ws: WebSocket) => {
      const conn: ClientConnection = {
        ws,
        subscribedRideIds: new Set<string>(),
      };
      this.clients.set(ws, conn);

      // Send initial welcome/handshake
      this.sendToWs(ws, {
        event: 'STATS_UPDATED',
        payload: { message: 'Connected to Rydwala Central Real-time Gateway' },
        timestamp: new Date().toISOString(),
      });

      ws.on('message', (messageRaw: string) => {
        try {
          const data = JSON.parse(messageRaw.toString());
          this.handleClientMessage(ws, data);
        } catch (err) {
          console.error('Error handling WS message:', err);
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
      });

      ws.on('error', (err) => {
        console.error('WS Error:', err);
        this.clients.delete(ws);
      });
    });

    console.log('⚡ Rydwala WebSocket Real-time Gateway initialized on /ws');
  }

  private handleClientMessage(ws: WebSocket, data: any) {
    const conn = this.clients.get(ws);
    if (!conn) return;

    if (data.type === 'IDENTIFY') {
      conn.userId = data.userId;
      conn.role = data.role;
      if (data.rideId) {
        conn.subscribedRideIds.add(data.rideId);
      }
    } else if (data.type === 'SUBSCRIBE_RIDE') {
      if (data.rideId) {
        conn.subscribedRideIds.add(data.rideId);
      }
    } else if (data.type === 'UNSUBSCRIBE_RIDE') {
      if (data.rideId) {
        conn.subscribedRideIds.delete(data.rideId);
      }
    }
  }

  private sendToWs(ws: WebSocket, message: WebSocketMessage) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  /**
   * Broadcast an event to a specific customer
   */
  public emitToCustomer(customerId: string, event: WebSocketEventType, payload: any) {
    const msg: WebSocketMessage = {
      event,
      payload,
      recipientId: customerId,
      timestamp: new Date().toISOString(),
    };

    for (const [ws, conn] of this.clients.entries()) {
      if (conn.userId === customerId || (payload.rideId && conn.subscribedRideIds.has(payload.rideId))) {
        this.sendToWs(ws, msg);
      }
    }
  }

  /**
   * Broadcast an event to a specific driver
   */
  public emitToDriver(driverId: string, event: WebSocketEventType, payload: any) {
    const msg: WebSocketMessage = {
      event,
      payload,
      recipientId: driverId,
      timestamp: new Date().toISOString(),
    };

    for (const [ws, conn] of this.clients.entries()) {
      if (conn.userId === driverId || (payload.rideId && conn.subscribedRideIds.has(payload.rideId))) {
        this.sendToWs(ws, msg);
      }
    }
  }

  /**
   * Broadcast a new ride request to all available online drivers
   */
  public broadcastToAvailableDrivers(event: WebSocketEventType, payload: any, targetVehicleType?: string) {
    const msg: WebSocketMessage = {
      event,
      payload,
      timestamp: new Date().toISOString(),
    };

    for (const [ws, conn] of this.clients.entries()) {
      if (conn.role === 'DRIVER') {
        this.sendToWs(ws, msg);
      }
    }
  }

  /**
   * Broadcast ride updates to all parties interested in a specific rideId (Customer, Driver, Admin)
   */
  public emitRideUpdate(rideId: string, event: WebSocketEventType, payload: any) {
    const msg: WebSocketMessage = {
      event,
      payload: { ...payload, rideId },
      timestamp: new Date().toISOString(),
    };

    for (const [ws, conn] of this.clients.entries()) {
      if (
        conn.subscribedRideIds.has(rideId) ||
        conn.userId === payload.customerId ||
        conn.userId === payload.driverId ||
        conn.role === 'ADMIN'
      ) {
        this.sendToWs(ws, msg);
      }
    }
  }

  /**
   * Broadcast to admin dashboard
   */
  public emitToAdmins(event: WebSocketEventType, payload: any) {
    const msg: WebSocketMessage = {
      event,
      payload,
      timestamp: new Date().toISOString(),
    };

    for (const [ws, conn] of this.clients.entries()) {
      if (conn.role === 'ADMIN') {
        this.sendToWs(ws, msg);
      }
    }
  }

  /**
   * General broadcast
   */
  public broadcast(event: WebSocketEventType, payload: any) {
    const msg: WebSocketMessage = {
      event,
      payload,
      timestamp: new Date().toISOString(),
    };

    for (const [ws] of this.clients.entries()) {
      this.sendToWs(ws, msg);
    }
  }

  public getConnectedClientsCount(): { total: number; customers: number; drivers: number; admins: number } {
    let customers = 0;
    let drivers = 0;
    let admins = 0;

    for (const conn of this.clients.values()) {
      if (conn.role === 'CUSTOMER') customers++;
      else if (conn.role === 'DRIVER') drivers++;
      else if (conn.role === 'ADMIN') admins++;
    }

    return {
      total: this.clients.size,
      customers,
      drivers,
      admins,
    };
  }
}

export const socketManager = SocketManager.getInstance();

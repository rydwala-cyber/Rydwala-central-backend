import pg from 'pg';
import bcrypt from 'bcryptjs';
import { readFileSync } from 'node:fs';
import {
  Customer, Driver, Ride, Payment, Transaction, ServiceArea, AdminUser, AppSettings,
} from '../types/index.ts';

const { Pool } = pg;

type Persistable = object;

type PersistFn<T> = (entityType: string, key: string, value: T | null) => void;

class PersistentMap<T extends Persistable> extends Map<string, T> {
  constructor(private readonly entityType: string, private readonly persist: PersistFn<T>) { super(); }
  override set(key: string, value: T): this {
    super.set(key, value);
    this.persist(this.entityType, key, value);
    return this;
  }
  override delete(key: string): boolean {
    const existed = super.delete(key);
    if (existed) this.persist(this.entityType, key, null);
    return existed;
  }
  override clear(): void {
    const keys = Array.from(this.keys());
    super.clear();
    for (const key of keys) this.persist(this.entityType, key, null);
  }
  hydrate(key: string, value: T) { super.set(key, value); }
}

export class DatabaseManager {
  private static instance: DatabaseManager;
  private pool: pg.Pool | null = null;
  public isPostgresConnected = false;
  private persistenceReady = false;
  private pendingWrites: Promise<unknown> = Promise.resolve();
  public readonly ready: Promise<void>;

  public customers: PersistentMap<Customer>;
  public drivers: PersistentMap<Driver>;
  public rides: PersistentMap<Ride>;
  public payments: PersistentMap<Payment>;
  public transactions: PersistentMap<Transaction>;
  public serviceAreas: PersistentMap<ServiceArea>;
  public adminUsers: PersistentMap<AdminUser>;
  public settings: AppSettings = {
    demoMode: process.env.DEMO_MODE === 'true',
    allowDemoOtp: process.env.DEMO_MODE === 'true',
    platformCommissionPercent: 15,
    surgeMultiplier: 1.0,
    upiMerchantId: process.env.UPI_MERCHANT_ID || 'rydwala@icici',
    upiMerchantName: process.env.UPI_MERCHANT_NAME || 'Rydwala Mobility Pvt Ltd',
    autoAssignDrivers: false,
  };

  private constructor() {
    const persist = <T extends Persistable>(entityType: string, key: string, value: T | null) => {
      this.enqueuePersist(entityType, key, value);
    };
    this.customers = new PersistentMap('customers', persist);
    this.drivers = new PersistentMap('drivers', persist);
    this.rides = new PersistentMap('rides', persist);
    this.payments = new PersistentMap('payments', persist);
    this.transactions = new PersistentMap('transactions', persist);
    this.serviceAreas = new PersistentMap('serviceAreas', persist);
    this.adminUsers = new PersistentMap('adminUsers', persist);

    this.ready = this.initialize();
  }

  public static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) DatabaseManager.instance = new DatabaseManager();
    return DatabaseManager.instance;
  }

  private enqueuePersist(entityType: string, key: string, value: Persistable | null) {
    if (!this.persistenceReady || !this.pool) return;
    this.pendingWrites = this.pendingWrites
      .then(async () => {
        if (!this.pool) return;
        if (value === null) {
          await this.pool.query('DELETE FROM entity_store WHERE entity_type=$1 AND entity_id=$2', [entityType, key]);
        } else {
          await this.pool.query(
            `INSERT INTO entity_store(entity_type, entity_id, data, updated_at)
             VALUES($1,$2,$3,NOW())
             ON CONFLICT(entity_type, entity_id) DO UPDATE SET data=EXCLUDED.data, updated_at=NOW()`,
            [entityType, key, JSON.stringify(value)]
          );
        }
      })
      .catch(err => console.error('PostgreSQL persistence error:', (err as Error).message));
  }

  private async initialize() {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      console.log('ℹ️ DATABASE_URL not set. Running with in-memory development storage.');
      await this.seedInitialData();
      return;
    }

    try {
      this.pool = new Pool({
        connectionString,
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 5000,
      });
      await this.pool.query('SELECT NOW()');
      await this.ensureSchema();
      await this.loadPersistentState();
      this.isPostgresConnected = true;
      this.persistenceReady = true;
      console.log('✅ PostgreSQL connected; persistent entity storage is active.');

      if (this.drivers.size === 0 && this.customers.size === 0) {
        await this.seedInitialData();
        await this.flushPersistence();
      }
    } catch (err) {
      this.isPostgresConnected = false;
      this.persistenceReady = false;
      console.warn('⚠️ PostgreSQL unavailable; using in-memory storage:', (err as Error).message);
      await this.seedInitialData();
    }
  }

  private async ensureSchema() {
    if (!this.pool) return;
    const normalizedSchema = readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');
    await this.pool.query(normalizedSchema);
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS entity_store (
        entity_type VARCHAR(64) NOT NULL,
        entity_id VARCHAR(128) NOT NULL,
        data JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        PRIMARY KEY(entity_type, entity_id)
      );
      CREATE INDEX IF NOT EXISTS idx_entity_store_type ON entity_store(entity_type);
    `);
  }

  private async loadPersistentState() {
    if (!this.pool) return;
    const { rows } = await this.pool.query('SELECT entity_type, entity_id, data FROM entity_store');
    for (const row of rows) {
      const data = row.data as Persistable;
      switch (row.entity_type) {
        case 'customers': this.customers.hydrate(row.entity_id, data as Customer); break;
        case 'drivers': this.drivers.hydrate(row.entity_id, data as Driver); break;
        case 'rides': this.rides.hydrate(row.entity_id, data as Ride); break;
        case 'payments': this.payments.hydrate(row.entity_id, data as Payment); break;
        case 'transactions': this.transactions.hydrate(row.entity_id, data as Transaction); break;
        case 'serviceAreas': this.serviceAreas.hydrate(row.entity_id, data as ServiceArea); break;
        case 'adminUsers': this.adminUsers.hydrate(row.entity_id, data as AdminUser); break;
      }
    }
  }

  private async flushPersistence() {
    await this.pendingWrites;
  }

  public async seedInitialData() {
    if (this.adminUsers.size > 0 && this.serviceAreas.size > 0) return;

    const hashedAdminPassword = await bcrypt.hash('admin123', 10);
    const hashedDriverPassword = await bcrypt.hash('driver123', 10);
    const hashedCustomerPassword = await bcrypt.hash('customer123', 10);

    const defaultAdmin: AdminUser = {
      adminId: 'ADM-001', username: 'admin', name: 'Rydwala Operations Admin',
      email: 'admin@rydwala.com', passwordHash: hashedAdminPassword,
      role: 'SUPER_ADMIN', createdAt: new Date().toISOString(),
    };
    this.adminUsers.set(defaultAdmin.adminId, defaultAdmin);

    const areas: ServiceArea[] = [
      { areaId:'AREA-PUNE', name:'Pune Metropolitan Region (PMRDA)', city:'Pune', state:'Maharashtra', centerLat:18.5204, centerLng:73.8567, radiusKm:35, baseFare:40, perKmRate:14, isActive:true, createdAt:new Date().toISOString() },
      { areaId:'AREA-MUMBAI', name:'Mumbai & Navi Mumbai', city:'Mumbai', state:'Maharashtra', centerLat:19.0760, centerLng:72.8777, radiusKm:45, baseFare:50, perKmRate:16, isActive:true, createdAt:new Date().toISOString() },
      { areaId:'AREA-NASHIK', name:'Nashik Smart City', city:'Nashik', state:'Maharashtra', centerLat:19.9975, centerLng:73.7898, radiusKm:25, baseFare:35, perKmRate:12, isActive:true, createdAt:new Date().toISOString() },
      { areaId:'AREA-NAGPUR', name:'Nagpur Central Metro', city:'Nagpur', state:'Maharashtra', centerLat:21.1458, centerLng:79.0882, radiusKm:30, baseFare:35, perKmRate:13, isActive:true, createdAt:new Date().toISOString() },
    ];
    areas.forEach(a => this.serviceAreas.set(a.areaId, a));

    const drivers: Driver[] = [
      { driverId:'DRV-101', name:'Sachin Patil', phone:'9876543210', email:'sachin.patil@rydwala.com', passwordHash:hashedDriverPassword, vehicleType:'AUTO', vehicleModel:'Bajaj Compact RE', vehicleNumber:'MH 12 AB 4590', licenseNumber:'MH12-2018-0045901', status:'ACTIVE', isOnline:true, isBusy:false, rating:4.92, totalRides:482, totalEarnings:38500, currentLocation:{lat:18.5314,lng:73.8446,address:'Shivajinagar, Pune, Maharashtra',heading:45,speed:0,updatedAt:new Date().toISOString()}, currentRideId:null, createdAt:'2026-01-10T08:00:00.000Z', updatedAt:new Date().toISOString() },
      { driverId:'DRV-102', name:'Rahul Deshmukh', phone:'9822334455', email:'rahul.d@rydwala.com', passwordHash:hashedDriverPassword, vehicleType:'SEDAN', vehicleModel:'Maruti Suzuki Dzire', vehicleNumber:'MH 12 CD 8821', licenseNumber:'MH12-2019-0099231', status:'ACTIVE', isOnline:true, isBusy:false, rating:4.88, totalRides:312, totalEarnings:62400, currentLocation:{lat:18.5204,lng:73.8567,address:'FC Road, Deccan, Pune',heading:90,speed:12,updatedAt:new Date().toISOString()}, currentRideId:null, createdAt:'2026-02-15T09:30:00.000Z', updatedAt:new Date().toISOString() },
      { driverId:'DRV-103', name:'Manoj Shinde', phone:'9977886655', email:'manoj.s@rydwala.com', passwordHash:hashedDriverPassword, vehicleType:'BIKE', vehicleModel:'Hero Splendor Plus', vehicleNumber:'MH 14 EF 1234', licenseNumber:'MH14-2021-0023411', status:'ACTIVE', isOnline:true, isBusy:false, rating:4.95, totalRides:650, totalEarnings:29800, currentLocation:{lat:18.5590,lng:73.7868,address:'Baner Main Road, Pune',heading:180,speed:0,updatedAt:new Date().toISOString()}, currentRideId:null, createdAt:'2026-01-20T11:00:00.000Z', updatedAt:new Date().toISOString() },
      { driverId:'DRV-104', name:'Amit Ghorpade', phone:'9123456789', email:'amit.g@rydwala.com', passwordHash:hashedDriverPassword, vehicleType:'MINI', vehicleModel:'Maruti WagonR', vehicleNumber:'MH 12 GH 5678', licenseNumber:'MH12-2020-0056782', status:'ACTIVE', isOnline:false, isBusy:false, rating:4.85, totalRides:221, totalEarnings:33150, currentLocation:{lat:18.5074,lng:73.8077,address:'Aundh, Pune, Maharashtra',heading:0,speed:0,updatedAt:new Date().toISOString()}, currentRideId:null, createdAt:'2026-03-05T10:00:00.000Z', updatedAt:new Date().toISOString() },
    ];
    drivers.forEach(d => this.drivers.set(d.driverId, d));

    const defaultCustomer: Customer = {
      customerId:'CUST-101', name:'Demo Rider', phone:'9000000001', email:'rider@rydwala.com',
      passwordHash:hashedCustomerPassword, status:'ACTIVE', rating:5, totalRides:12,
      createdAt:'2026-01-01T08:00:00.000Z', updatedAt:new Date().toISOString(),
    };
    this.customers.set(defaultCustomer.customerId, defaultCustomer);
  }

  public async close() {
    await this.flushPersistence();
    await this.pool?.end();
  }
}

export const db = DatabaseManager.getInstance();

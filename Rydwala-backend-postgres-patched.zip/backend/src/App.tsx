import React, { useState, useEffect } from 'react';
import { CustomerAppView } from './components/CustomerAppView.tsx';
import { DriverAppView } from './components/DriverAppView.tsx';
import { AdminPortalView } from './components/AdminPortalView.tsx';
import { ApiExplorerView } from './components/ApiExplorerView.tsx';
import { MultiDeviceSyncView } from './components/MultiDeviceSyncView.tsx';
import { rydwalaManager } from './services/rydwalaService.ts';
import {
  Smartphone,
  Server,
  Shield,
  Layers,
  SplitSquareVertical,
  Activity,
  ToggleLeft,
  ToggleRight,
  Database,
  Radio,
} from 'lucide-react';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<'sync' | 'customer' | 'driver' | 'admin' | 'explorer'>('sync');
  const [isDemoMode, setIsDemoMode] = useState(rydwalaManager.isDemoMode());
  const [backendHealth, setBackendHealth] = useState<any>(null);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 10000);
    return () => clearInterval(interval);
  }, []);

  const checkHealth = async () => {
    try {
      const res = await fetch('/api/v1/system/health');
      if (res.ok) {
        const data = await res.json();
        setBackendHealth(data);
      }
    } catch {
      setBackendHealth({ status: 'offline' });
    }
  };

  const handleToggleDemoMode = async () => {
    const next = !isDemoMode;
    setIsDemoMode(next);
    rydwalaManager.setDemoMode(next);
    try {
      await fetch('/api/v1/system/toggle-demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: next }),
      });
      checkHealth();
    } catch {
      // ignore
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black">
      {/* Top Rydwala Central Master Navigation Bar */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 backdrop-blur-md bg-slate-900/90 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Logo & Platform Info */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              R
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-extrabold text-base tracking-tight text-white">RYDWALA</h1>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                  Central Backend
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Production REST + WebSocket Real-Time Infrastructure</p>
            </div>
          </div>

          {/* Navigation View Switcher */}
          <nav className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-medium overflow-x-auto">
            <button
              onClick={() => setActiveScreen('sync')}
              className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition whitespace-nowrap ${
                activeScreen === 'sync'
                  ? 'bg-teal-600 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Multi-Device Sync</span>
            </button>

            <button
              onClick={() => setActiveScreen('customer')}
              className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition whitespace-nowrap ${
                activeScreen === 'customer'
                  ? 'bg-emerald-600 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Customer App</span>
            </button>

            <button
              onClick={() => setActiveScreen('driver')}
              className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition whitespace-nowrap ${
                activeScreen === 'driver'
                  ? 'bg-amber-600 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-300" />
              <span>Driver Partner</span>
            </button>

            <button
              onClick={() => setActiveScreen('admin')}
              className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition whitespace-nowrap ${
                activeScreen === 'admin'
                  ? 'bg-indigo-600 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Console</span>
            </button>

            <button
              onClick={() => setActiveScreen('explorer')}
              className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition whitespace-nowrap ${
                activeScreen === 'explorer'
                  ? 'bg-cyan-600 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>API & DB Explorer</span>
            </button>
          </nav>

          {/* Backend Status & Mode Switcher */}
          <div className="flex items-center space-x-3 text-xs">
            {/* Health pill */}
            <div className="hidden sm:flex items-center space-x-1.5 px-2.5 py-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-300">
              <span className={`w-2 h-2 rounded-full ${backendHealth?.status === 'healthy' ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`}></span>
              <span>Port 3000 API: {backendHealth?.status === 'healthy' ? 'Live' : 'Checking'}</span>
            </div>

            {/* Central vs Demo Mode Toggle */}
            <button
              type="button"
              onClick={handleToggleDemoMode}
              className={`px-3 py-1.5 rounded-xl border flex items-center space-x-1.5 transition font-semibold text-xs ${
                isDemoMode
                  ? 'bg-amber-950/80 border-amber-600/50 text-amber-300'
                  : 'bg-emerald-950/80 border-emerald-600/50 text-emerald-300'
              }`}
            >
              {isDemoMode ? <ToggleLeft className="w-4 h-4" /> : <ToggleRight className="w-4 h-4" />}
              <span>{isDemoMode ? 'DEMO_MODE (OTP 1234)' : 'CENTRAL BACKEND (Live)'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col justify-center">
        {activeScreen === 'sync' && <MultiDeviceSyncView />}
        {activeScreen === 'customer' && <CustomerAppView />}
        {activeScreen === 'driver' && <DriverAppView />}
        {activeScreen === 'admin' && <AdminPortalView />}
        {activeScreen === 'explorer' && <ApiExplorerView />}
      </main>

      {/* Global Status Footer */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 py-3 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Rydwala Central Backend Engine • PostgreSQL Relational Models • Real-Time WebSockets</span>
          <div className="flex items-center space-x-3 text-[11px] text-slate-400">
            <span className="flex items-center"><Database className="w-3 h-3 mr-1 text-teal-400" /> PostgreSQL Ready</span>
            <span className="flex items-center"><Radio className="w-3 h-3 mr-1 text-emerald-400" /> WS Gateway (/ws)</span>
            <span className="flex items-center"><Shield className="w-3 h-3 mr-1 text-indigo-400" /> JWT Auth</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

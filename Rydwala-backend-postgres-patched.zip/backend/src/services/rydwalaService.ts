import { realBackendService } from './realBackendService.ts';
import { demoService } from './demoService.ts';
import { IRydwalaService } from './types.ts';

class RydwalaServiceManager {
  private useDemoMode = false;

  constructor() {
    try {
      const stored = localStorage.getItem('rydwala_demo_mode_override');
      if (stored !== null) {
        this.useDemoMode = stored === 'true';
      }
    } catch {
      // ignore
    }
  }

  public isDemoMode(): boolean {
    return this.useDemoMode;
  }

  public setDemoMode(enable: boolean) {
    this.useDemoMode = enable;
    try {
      localStorage.setItem('rydwala_demo_mode_override', String(enable));
    } catch {
      // ignore
    }
  }

  public getService(): IRydwalaService {
    return this.useDemoMode ? demoService : realBackendService;
  }
}

export const rydwalaManager = new RydwalaServiceManager();
export const rydwalaService: IRydwalaService = new Proxy({} as IRydwalaService, {
  get(_target, prop: keyof IRydwalaService) {
    const service = rydwalaManager.getService();
    const val = (service as any)[prop];
    if (typeof val === 'function') {
      return val.bind(service);
    }
    return val;
  },
});

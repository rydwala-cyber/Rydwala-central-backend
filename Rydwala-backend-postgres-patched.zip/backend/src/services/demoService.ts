import {
  CustomerData,
  DriverData,
  IRydwalaService,
  PaymentMethod,
  RideData,
  RideOptionType,
} from './types.ts';

/**
 * Demo Service - Isolated mock fallback when DEMO_MODE = true
 * Allows testing with Demo OTP (1234) in demo mode
 */
export class DemoService implements IRydwalaService {
  private mockRide: RideData | null = null;
  private mockDriver: DriverData = {
    driverId: 'DEMO-DRV-101',
    name: 'Santosh Jadhav (Demo Driver)',
    phone: '9822001122',
    vehicleType: 'AUTO',
    vehicleModel: 'Bajaj Compact Auto',
    vehicleNumber: 'MH 12 DM 9999',
    status: 'ACTIVE',
    isOnline: true,
    isBusy: false,
    rating: 4.9,
    totalRides: 120,
    totalEarnings: 15400,
    currentLocation: {
      lat: 18.5204,
      lng: 73.8567,
      address: 'Demo Deccan Gymkhana, Pune',
    },
  };

  async customerLogin(phone: string, name?: string): Promise<{ customer: CustomerData; token: string }> {
    return {
      customer: {
        customerId: 'DEMO-CUST-01',
        name: name || 'Demo Rider',
        phone,
        status: 'ACTIVE',
        totalRides: 5,
      },
      token: 'demo-jwt-token-customer',
    };
  }

  async driverLogin(_phoneOrId: string): Promise<{ driver: DriverData; token: string }> {
    return {
      driver: this.mockDriver,
      token: 'demo-jwt-token-driver',
    };
  }

  async createRide(params: {
    customerId: string;
    pickup: string;
    drop: string;
    pickupLat: number;
    pickupLng: number;
    dropLat: number;
    dropLng: number;
    rideOption: RideOptionType;
    paymentMethod?: PaymentMethod;
  }): Promise<RideData> {
    const rideId = `DEMO-RIDE-${Math.floor(1000 + Math.random() * 9000)}`;
    this.mockRide = {
      rideId,
      customerId: params.customerId,
      driverId: null,
      customerName: 'Demo Rider',
      customerPhone: '9890001122',
      driverName: null,
      driverPhone: null,
      vehicleModel: null,
      vehicleNumber: null,
      vehicleType: params.rideOption,
      pickup: params.pickup,
      drop: params.drop,
      pickupLat: params.pickupLat,
      pickupLng: params.pickupLng,
      dropLat: params.dropLat,
      dropLng: params.dropLng,
      distanceKm: 4.8,
      fare: 85,
      rideOption: params.rideOption,
      otp: '1234',
      otpVerified: false,
      status: 'SEARCHING',
      paymentMethod: params.paymentMethod || 'CASH',
      paymentStatus: 'PAYMENT_PENDING',
      createdAt: new Date().toISOString(),
    };
    return this.mockRide;
  }

  async getRide(_rideId: string): Promise<RideData> {
    if (!this.mockRide) {
      throw new Error('No active demo ride found.');
    }
    return this.mockRide;
  }

  async acceptRide(_rideId: string, _driverId: string): Promise<RideData> {
    if (!this.mockRide) throw new Error('No demo ride');
    this.mockRide.driverId = this.mockDriver.driverId;
    this.mockRide.driverName = this.mockDriver.name;
    this.mockRide.driverPhone = this.mockDriver.phone;
    this.mockRide.vehicleModel = this.mockDriver.vehicleModel;
    this.mockRide.vehicleNumber = this.mockDriver.vehicleNumber;
    this.mockRide.status = 'DRIVER_ASSIGNED';
    return this.mockRide;
  }

  async markArrived(_rideId: string, _driverId: string): Promise<RideData> {
    if (!this.mockRide) throw new Error('No demo ride');
    this.mockRide.status = 'DRIVER_ARRIVED';
    this.mockRide.arrivedAt = new Date().toISOString();
    return this.mockRide;
  }

  async verifyOtp(_rideId: string, _driverId: string, otp: string): Promise<{ success: boolean; ride: RideData }> {
    if (!this.mockRide) throw new Error('No demo ride');
    if (otp !== '1234' && otp !== this.mockRide.otp) {
      throw new Error('Invalid OTP! Demo OTP is 1234');
    }
    this.mockRide.otpVerified = true;
    this.mockRide.status = 'RIDE_STARTED';
    this.mockRide.startedAt = new Date().toISOString();
    return { success: true, ride: this.mockRide };
  }

  async completeRide(_rideId: string, _driverId: string): Promise<RideData> {
    if (!this.mockRide) throw new Error('No demo ride');
    this.mockRide.status = 'COMPLETED';
    this.mockRide.completedAt = new Date().toISOString();
    return this.mockRide;
  }

  async cancelRide(_rideId: string, cancelledBy: 'CUSTOMER' | 'DRIVER' | 'ADMIN', reason?: string): Promise<RideData> {
    if (!this.mockRide) throw new Error('No demo ride');
    this.mockRide.status = 'CANCELLED';
    this.mockRide.cancellationReason = reason || `Cancelled by ${cancelledBy}`;
    return this.mockRide;
  }

  async setDriverOnline(_driverId: string, isOnline: boolean): Promise<DriverData> {
    this.mockDriver.isOnline = isOnline;
    return this.mockDriver;
  }

  async updateDriverLocation(_driverId: string, coords: { lat: number; lng: number }): Promise<any> {
    this.mockDriver.currentLocation = {
      lat: coords.lat,
      lng: coords.lng,
      address: 'Demo location',
    };
    return { success: true };
  }

  async collectCashPayment(_rideId: string, _driverId: string, _amount?: number): Promise<any> {
    if (this.mockRide) {
      this.mockRide.paymentStatus = 'PAYMENT_SUCCESSFUL';
      this.mockRide.paymentMethod = 'CASH';
    }
    return { success: true, status: 'PAYMENT_SUCCESSFUL' };
  }

  async getUpiIntent(_rideId: string): Promise<any> {
    return {
      amount: this.mockRide?.fare || 85,
      upiId: 'demo@upi',
      merchantName: 'Rydwala Demo',
      qrPayload: 'upi://pay?pa=demo@upi&pn=Rydwala&am=85',
    };
  }

  async simulateUpiWebhook(_rideId: string, _amount: number, _transactionRef: string): Promise<any> {
    if (this.mockRide) {
      this.mockRide.paymentStatus = 'PAYMENT_SUCCESSFUL';
      this.mockRide.paymentMethod = 'UPI';
    }
    return { success: true, status: 'PAYMENT_SUCCESSFUL' };
  }
}

export const demoService = new DemoService();

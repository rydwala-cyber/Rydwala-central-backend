/**
 * Rydwala Central API & WebSocket Client
 * Production-ready HTTP and WebSocket communication layer
 */

export const API_BASE_URL = '/api/v1';

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  [key: string]: any;
}

class ApiClient {
  private token: string | null = null;
  private currentUserId: string | null = null;
  private currentUserRole: string | null = null;

  constructor() {
    // Check saved session credentials
    try {
      this.token = sessionStorage.getItem('rydwala_jwt_token') || null;
      this.currentUserId = sessionStorage.getItem('rydwala_user_id') || null;
      this.currentUserRole = sessionStorage.getItem('rydwala_user_role') || null;
    } catch {
      // ignore
    }
  }

  public setAuth(token: string, userId: string, role: string) {
    this.token = token;
    this.currentUserId = userId;
    this.currentUserRole = role;
    try {
      sessionStorage.setItem('rydwala_jwt_token', token);
      sessionStorage.setItem('rydwala_user_id', userId);
      sessionStorage.setItem('rydwala_user_role', role);
    } catch {
      // ignore
    }
  }

  public clearAuth() {
    this.token = null;
    this.currentUserId = null;
    this.currentUserRole = null;
    try {
      sessionStorage.removeItem('rydwala_jwt_token');
      sessionStorage.removeItem('rydwala_user_id');
      sessionStorage.removeItem('rydwala_user_role');
    } catch {
      // ignore
    }
  }

  public async request<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    if (this.currentUserId) {
      headers['x-user-id'] = this.currentUserId;
    }
    if (this.currentUserRole) {
      headers['x-user-role'] = this.currentUserRole;
    }

    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;

    const res = await fetch(url, {
      ...options,
      headers,
    });

    const data = await res.json().catch(() => ({ success: false, message: 'Invalid JSON response from server' }));

    if (!res.ok) {
      throw new Error(data.message || `API Error ${res.status}: ${res.statusText}`);
    }

    return data;
  }

  public get<T = any>(endpoint: string) {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  public post<T = any>(endpoint: string, body?: any) {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public patch<T = any>(endpoint: string, body?: any) {
    return this.request<T>(endpoint, {
      method: 'PATCH',
      body: body ? JSON.stringify(body) : undefined,
    });
  }
}

export const apiClient = new ApiClient();

// WebSocket Real-time Connector
export class RydwalaSocketClient {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<(payload: any) => void>> = new Map();
  private isConnecting = false;
  private reconnectTimer: any = null;
  private currentRideId: string | null = null;
  private userId: string | null = null;
  private role: string | null = null;

  public connect(userId?: string, role?: string) {
    if (userId) this.userId = userId;
    if (role) this.role = role;

    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      if (userId && role) {
        this.identify(userId, role);
      }
      return;
    }

    if (this.isConnecting) return;
    this.isConnecting = true;

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        console.log('⚡ Connected to Rydwala WebSocket Gateway');
        if (this.userId && this.role) {
          this.identify(this.userId, this.role);
        }
        if (this.currentRideId) {
          this.subscribeRide(this.currentRideId);
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          const { event: eventName, payload } = data;
          const callbacks = this.listeners.get(eventName);
          if (callbacks) {
            callbacks.forEach(cb => cb(payload));
          }
          // Also invoke wildcard listener
          const allCallbacks = this.listeners.get('*');
          if (allCallbacks) {
            allCallbacks.forEach(cb => cb(data));
          }
        } catch (e) {
          console.error('Error parsing WS message:', e);
        }
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.ws = null;
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => this.connect(), 3000);
      };

      this.ws.onerror = (err) => {
        this.isConnecting = false;
        console.warn('WS Gateway connection retry scheduled...');
      };
    } catch (err) {
      this.isConnecting = false;
    }
  }

  public identify(userId: string, role: string, rideId?: string) {
    this.userId = userId;
    this.role = role;
    if (rideId) this.currentRideId = rideId;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'IDENTIFY',
        userId,
        role,
        rideId,
      }));
    }
  }

  public subscribeRide(rideId: string) {
    this.currentRideId = rideId;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'SUBSCRIBE_RIDE',
        rideId,
      }));
    }
  }

  public on(event: string, callback: (payload: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.off(event, callback);
  }

  public off(event: string, callback: (payload: any) => void) {
    const set = this.listeners.get(event);
    if (set) {
      set.delete(callback);
    }
  }
}

export const socketClient = new RydwalaSocketClient();

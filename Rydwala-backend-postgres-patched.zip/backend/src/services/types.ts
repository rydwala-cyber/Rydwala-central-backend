export type RideOptionType = 'BIKE' | 'AUTO' | 'MINI' | 'SEDAN' | 'XL';

export type RideStatus =
  | 'SEARCHING'
  | 'DRIVER_ASSIGNED'
  | 'DRIVER_ACCEPTED'
  | 'DRIVER_ARRIVING'
  | 'DRIVER_ARRIVED'
  | 'RIDE_STARTED'
  | 'ON_TRIP'
  | 'COMPLETED'
  | 'CANCELLED';

export type PaymentMethod = 'CASH' | 'UPI' | 'WALLET' | 'CARD';
export type PaymentStatus = 'PAYMENT_PENDING' | 'PAYMENT_SUCCESSFUL' | 'PAYMENT_FAILED';

export interface CustomerData {
  customerId: string;
  name: string;
  phone: string;
  email?: string;
  status: string;
  totalRides?: number;
}

export interface DriverData {
  driverId: string;
  name: string;
  phone: string;
  vehicleType: RideOptionType;
  vehicleModel: string;
  vehicleNumber: string;
  status: string;
  isOnline: boolean;
  isBusy: boolean;
  rating: number;
  totalRides: number;
  totalEarnings: number;
  currentLocation?: {
    lat: number;
    lng: number;
    address?: string;
    heading?: number;
    speed?: number;
  };
}

export interface RideData {
  rideId: string;
  customerId: string;
  driverId: string | null;
  customerName: string;
  customerPhone: string;
  driverName: string | null;
  driverPhone: string | null;
  vehicleModel: string | null;
  vehicleNumber: string | null;
  vehicleType: RideOptionType;
  pickup: string;
  drop: string;
  pickupLat: number;
  pickupLng: number;
  dropLat: number;
  dropLng: number;
  distanceKm: number;
  fare: number;
  rideOption: RideOptionType;
  otp: string;
  otpVerified: boolean;
  status: RideStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  cancellationReason?: string | null;
  createdAt: string;
  arrivedAt?: string | null;
  startedAt?: string | null;
  completedAt?: string | null;
}

export interface IRydwalaService {
  // Auth
  customerLogin(phone: string, name?: string): Promise<{ customer: CustomerData; token: string }>;
  driverLogin(phoneOrId: string): Promise<{ driver: DriverData; token: string }>;

  // Rides
  createRide(params: {
    customerId: string;
    pickup: string;
    drop: string;
    pickupLat: number;
    pickupLng: number;
    dropLat: number;
    dropLng: number;
    rideOption: RideOptionType;
    paymentMethod?: PaymentMethod;
  }): Promise<RideData>;

  getRide(rideId: string): Promise<RideData>;
  acceptRide(rideId: string, driverId: string): Promise<RideData>;
  markArrived(rideId: string, driverId: string): Promise<RideData>;
  verifyOtp(rideId: string, driverId: string, otp: string): Promise<{ success: boolean; ride: RideData }>;
  completeRide(rideId: string, driverId: string): Promise<RideData>;
  cancelRide(rideId: string, cancelledBy: 'CUSTOMER' | 'DRIVER' | 'ADMIN', reason?: string): Promise<RideData>;

  // Driver
  setDriverOnline(driverId: string, isOnline: boolean): Promise<DriverData>;
  updateDriverLocation(driverId: string, coords: { lat: number; lng: number; heading?: number }): Promise<any>;

  // Payment
  collectCashPayment(rideId: string, driverId: string, amount?: number): Promise<any>;
  getUpiIntent(rideId: string): Promise<any>;
  simulateUpiWebhook(rideId: string, amount: number, transactionRef: string): Promise<any>;
}

import { apiClient } from './apiClient.ts';
import {
  CustomerData,
  DriverData,
  IRydwalaService,
  PaymentMethod,
  RideData,
  RideOptionType,
} from './types.ts';

export class RealBackendService implements IRydwalaService {
  async customerLogin(phone: string, name?: string): Promise<{ customer: CustomerData; token: string }> {
    const res = await apiClient.post('/auth/customer/login', {
      phone,
      name: name || `Customer ${phone.slice(-4)}`,
    });
    if (res.token) {
      apiClient.setAuth(res.token, res.customer.customerId, 'CUSTOMER');
    }
    return {
      customer: res.customer,
      token: res.token,
    };
  }

  async driverLogin(phoneOrId: string): Promise<{ driver: DriverData; token: string }> {
    const isId = phoneOrId.startsWith('DRV-');
    const res = await apiClient.post('/auth/driver/login', isId ? { driverId: phoneOrId } : { phone: phoneOrId });
    if (res.token) {
      apiClient.setAuth(res.token, res.driver.driverId, 'DRIVER');
    }
    return {
      driver: res.driver,
      token: res.token,
    };
  }

  async createRide(params: {
    customerId: string;
    pickup: string;
    drop: string;
    pickupLat: number;
    pickupLng: number;
    dropLat: number;
    dropLng: number;
    rideOption: RideOptionType;
    paymentMethod?: PaymentMethod;
  }): Promise<RideData> {
    const res = await apiClient.post('/rides', params);
    return res.ride;
  }

  async getRide(rideId: string): Promise<RideData> {
    const res = await apiClient.get(`/rides/${rideId}`);
    return res.ride;
  }

  async acceptRide(rideId: string, driverId: string): Promise<RideData> {
    const res = await apiClient.post(`/rides/${rideId}/accept`, { driverId });
    return res.ride;
  }

  async markArrived(rideId: string, driverId: string): Promise<RideData> {
    const res = await apiClient.post(`/rides/${rideId}/arrived`, { driverId });
    return res.ride;
  }

  async verifyOtp(rideId: string, driverId: string, otp: string): Promise<{ success: boolean; ride: RideData }> {
    const res = await apiClient.post(`/rides/${rideId}/verify-otp`, { driverId, otp });
    return {
      success: res.success,
      ride: res.ride,
    };
  }

  async completeRide(rideId: string, driverId: string): Promise<RideData> {
    const res = await apiClient.post(`/rides/${rideId}/complete`, { driverId });
    return res.ride;
  }

  async cancelRide(rideId: string, cancelledBy: 'CUSTOMER' | 'DRIVER' | 'ADMIN', reason?: string): Promise<RideData> {
    const res = await apiClient.post(`/rides/${rideId}/cancel`, { cancelledBy, reason });
    return res.ride;
  }

  async setDriverOnline(driverId: string, isOnline: boolean): Promise<DriverData> {
    const res = await apiClient.post(`/drivers/${driverId}/online`, { isOnline });
    return res.driver;
  }

  async updateDriverLocation(driverId: string, coords: { lat: number; lng: number; heading?: number; address?: string }): Promise<any> {
    return apiClient.post(`/drivers/${driverId}/location`, coords);
  }

  async collectCashPayment(rideId: string, driverId: string, amount?: number): Promise<any> {
    return apiClient.post('/payments/cash', { rideId, driverId, amount });
  }

  async getUpiIntent(rideId: string): Promise<any> {
    return apiClient.post('/payments/upi/intent', { rideId });
  }

  async simulateUpiWebhook(rideId: string, amount: number, transactionRef: string): Promise<any> {
    return apiClient.post('/payments/upi/webhook', {
      rideId,
      amount,
      transactionRef,
      status: 'SUCCESS',
    });
  }
}

export const realBackendService = new RealBackendService();

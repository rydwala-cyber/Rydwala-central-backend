import React, { useState, useEffect } from 'react';
import {
  Car,
  Power,
  MapPin,
  ShieldAlert,
  CheckCircle2,
  DollarSign,
  AlertCircle,
  Phone,
  Navigation,
  Compass,
  RefreshCw,
  Award,
} from 'lucide-react';
import { rydwalaService, rydwalaManager } from '../services/rydwalaService.ts';
import { socketClient } from '../services/apiClient.ts';
import { DriverData, RideData } from '../services/types.ts';

export const DriverAppView: React.FC<{
  onRideChange?: (ride: RideData | null) => void;
  externalRideId?: string | null;
}> = ({ onRideChange, externalRideId }) => {
  const [driverId, setDriverId] = useState('DRV-101');
  const [driver, setDriver] = useState<DriverData>({
    driverId: 'DRV-101',
    name: 'Sachin Patil',
    phone: '9876543210',
    vehicleType: 'AUTO',
    vehicleModel: 'Bajaj Compact RE',
    vehicleNumber: 'MH 12 AB 4590',
    status: 'ACTIVE',
    isOnline: true,
    isBusy: false,
    rating: 4.92,
    totalRides: 482,
    totalEarnings: 38500,
    currentLocation: {
      lat: 18.5314,
      lng: 73.8446,
      address: 'Shivajinagar, Pune',
    },
  });

  const [activeRide, setActiveRide] = useState<RideData | null>(null);
  const [incomingRequest, setIncomingRequest] = useState<any | null>(null);
  const [inputOtp, setInputOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sync external ride ID
  useEffect(() => {
    if (externalRideId && (!activeRide || activeRide.rideId !== externalRideId)) {
      rydwalaService.getRide(externalRideId).then(r => {
        if (r.driverId === driverId || !r.driverId) {
          setActiveRide(r);
          onRideChange?.(r);
        }
      }).catch(() => {});
    }
  }, [externalRideId]);

  // WebSocket event listeners for Driver
  useEffect(() => {
    socketClient.connect(driverId, 'DRIVER');
    socketClient.identify(driverId, 'DRIVER', activeRide?.rideId);

    // Listen for incoming ride requests from backend
    const unsubNewRide = socketClient.on('NEW_RIDE_REQUEST', (payload: any) => {
      console.log('Driver WS: NEW_RIDE_REQUEST', payload);
      if (driver.isOnline && !activeRide) {
        setIncomingRequest(payload.ride || payload);
      }
    });

    const unsubCancelled = socketClient.on('CANCELLED', () => {
      setActiveRide(null);
      setIncomingRequest(null);
      onRideChange?.(null);
      setSuccessMessage('Ride was cancelled.');
    });

    const unsubPayment = socketClient.on('PAYMENT_SUCCESSFUL', () => {
      refreshRide();
    });

    return () => {
      unsubNewRide();
      unsubCancelled();
      unsubPayment();
    };
  }, [driverId, driver.isOnline, activeRide?.rideId]);

  const refreshRide = async () => {
    if (activeRide?.rideId) {
      try {
        const updated = await rydwalaService.getRide(activeRide.rideId);
        setActiveRide(updated);
        onRideChange?.(updated);
      } catch (e) {
        console.error('Driver refresh error:', e);
      }
    }
  };

  const handleToggleOnline = async () => {
    setLoading(true);
    setError(null);
    try {
      const newStatus = !driver.isOnline;
      await rydwalaService.setDriverOnline(driverId, newStatus);
      setDriver(prev => ({ ...prev, isOnline: newStatus }));
      if (!newStatus) {
        setIncomingRequest(null);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptRide = async (rideToAccept?: any) => {
    const target = rideToAccept || incomingRequest;
    if (!target) return;

    setLoading(true);
    setError(null);
    try {
      const accepted = await rydwalaService.acceptRide(target.rideId, driverId);
      setActiveRide(accepted);
      setIncomingRequest(null);
      onRideChange?.(accepted);
      socketClient.subscribeRide(accepted.rideId);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleArrived = async () => {
    if (!activeRide) return;
    setLoading(true);
    setError(null);
    try {
      const updated = await rydwalaService.markArrived(activeRide.rideId, driverId);
      setActiveRide(updated);
      onRideChange?.(updated);
      setSuccessMessage('Marked arrived! Ask customer for 4-digit OTP.');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtpAndStart = async () => {
    if (!activeRide || !inputOtp) return;
    setLoading(true);
    setError(null);
    try {
      const result = await rydwalaService.verifyOtp(activeRide.rideId, driverId, inputOtp);
      setActiveRide(result.ride);
      onRideChange?.(result.ride);
      setInputOtp('');
      setSuccessMessage('OTP Verified! Ride has officially started.');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteRide = async () => {
    if (!activeRide) return;
    setLoading(true);
    setError(null);
    try {
      const completed = await rydwalaService.completeRide(activeRide.rideId, driverId);
      setActiveRide(completed);
      onRideChange?.(completed);
      setDriver(prev => ({
        ...prev,
        totalEarnings: prev.totalEarnings + Math.round(completed.fare * 0.85),
        totalRides: prev.totalRides + 1,
      }));
      setSuccessMessage('Ride completed! Please collect payment.');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleCollectCash = async () => {
    if (!activeRide) return;
    setLoading(true);
    setError(null);
    try {
      await rydwalaService.collectCashPayment(activeRide.rideId, driverId, activeRide.fare);
      await refreshRide();
      setSuccessMessage('Cash payment collected and confirmed on Central Backend!');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulateGpsMove = async () => {
    if (!activeRide) return;
    try {
      const newLat = (driver.currentLocation?.lat || 18.5204) + (Math.random() - 0.5) * 0.005;
      const newLng = (driver.currentLocation?.lng || 73.8567) + (Math.random() - 0.5) * 0.005;
      await rydwalaService.updateDriverLocation(driverId, {
        lat: newLat,
        lng: newLng,
        heading: 90,
      });
      setDriver(prev => ({
        ...prev,
        currentLocation: { lat: newLat, lng: newLng, address: 'In Transit' },
      }));
      setSuccessMessage('Live GPS updated to Central Backend & Customer!');
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <div className="bg-slate-900 text-slate-100 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden max-w-md w-full mx-auto flex flex-col min-h-[680px]">
      {/* Driver Header */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-700 p-4 text-white flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2">
          <div className="w-9 h-9 rounded-xl bg-white text-amber-700 flex items-center justify-center font-black text-xl shadow">
            D
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight leading-none">Rydwala Driver Partner</h1>
            <p className="text-xs text-amber-100 opacity-90">{driver.name}</p>
          </div>
        </div>

        {/* Online / Offline Toggle Button */}
        <button
          type="button"
          disabled={loading}
          onClick={handleToggleOnline}
          className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center space-x-1.5 transition shadow ${
            driver.isOnline
              ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
          }`}
        >
          <Power className="w-3.5 h-3.5" />
          <span>{driver.isOnline ? 'ONLINE' : 'OFFLINE'}</span>
        </button>
      </div>

      {/* Main Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-4 overflow-y-auto">
        {error && (
          <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-red-200 text-xs flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-800 rounded-xl text-emerald-200 text-xs flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Driver Stats Ribbon */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Today's Earn</span>
            <span className="font-bold text-sm text-emerald-400 font-mono">₹{driver.totalEarnings}</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Completed</span>
            <span className="font-bold text-sm text-amber-400 font-mono">{driver.totalRides}</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Rating</span>
            <span className="font-bold text-sm text-white flex items-center justify-center">
              <Award className="w-3 h-3 text-amber-400 mr-1" /> {driver.rating}
            </span>
          </div>
        </div>

        {/* Vehicle Badge */}
        <div className="bg-slate-800/40 p-2.5 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <Car className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">{driver.vehicleModel}</span>
          </div>
          <span className="font-mono font-bold text-amber-400 bg-slate-900 px-2 py-0.5 rounded">
            {driver.vehicleNumber}
          </span>
        </div>

        {/* INCOMING RIDE REQUEST MODAL / BANNER */}
        {incomingRequest && !activeRide && (
          <div className="bg-gradient-to-br from-amber-950/80 via-slate-800 to-slate-900 border-2 border-amber-500 rounded-2xl p-4 space-y-3 animate-pulse shadow-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mr-2 animate-ping"></span>
                New Ride Alert!
              </span>
              <span className="text-base font-bold font-mono text-white">₹{incomingRequest.fare}</span>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="text-slate-300">
                <strong className="text-slate-400">Pickup:</strong> {incomingRequest.pickup}
              </div>
              <div className="text-slate-300">
                <strong className="text-slate-400">Drop:</strong> {incomingRequest.drop}
              </div>
              <div className="text-slate-400 font-mono text-[11px]">
                Distance: {incomingRequest.distanceKm} km • Option: {incomingRequest.rideOption}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIncomingRequest(null)}
                className="bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold py-2.5 rounded-xl text-xs"
              >
                Pass / Skip
              </button>
              <button
                type="button"
                onClick={() => handleAcceptRide(incomingRequest)}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs shadow-lg shadow-emerald-500/30"
              >
                Accept Ride
              </button>
            </div>
          </div>
        )}

        {/* ACTIVE TRIP MANAGEMENT */}
        {activeRide && activeRide.status !== 'CANCELLED' ? (
          <div className="space-y-3.5">
            {/* Active Ride Card Header */}
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Active Trip</span>
                <span className="font-bold text-xs text-amber-400 font-mono">{activeRide.rideId}</span>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-950 text-amber-300 border border-amber-600/40">
                {activeRide.status.replace(/_/g, ' ')}
              </span>
            </div>

            {/* Customer Details */}
            <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center">
                  👤
                </div>
                <div>
                  <div className="font-bold text-slate-200">{activeRide.customerName}</div>
                  <div className="text-slate-400 font-mono text-[11px]">+91 {activeRide.customerPhone}</div>
                </div>
              </div>
              <a
                href={`tel:${activeRide.customerPhone}`}
                className="w-8 h-8 rounded-full bg-emerald-600/20 text-emerald-400 flex items-center justify-center hover:bg-emerald-600/30 border border-emerald-500/30"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>

            {/* Location Route */}
            <div className="bg-slate-800/40 rounded-xl p-3 border border-slate-700/60 space-y-1.5 text-xs">
              <div className="flex items-start space-x-1.5 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="truncate"><strong className="text-slate-400">Pickup:</strong> {activeRide.pickup}</span>
              </div>
              <div className="flex items-start space-x-1.5 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                <span className="truncate"><strong className="text-slate-400">Drop:</strong> {activeRide.drop}</span>
              </div>
            </div>

            {/* ACTION STEP 1: Tap Arrived at Pickup */}
            {['DRIVER_ASSIGNED', 'DRIVER_ACCEPTED', 'DRIVER_ARRIVING'].includes(activeRide.status) && (
              <div className="space-y-2">
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleArrived}
                  className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-3 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20"
                >
                  <Navigation className="w-4 h-4" />
                  <span>I Have Arrived at Pickup Location</span>
                </button>
                <p className="text-[11px] text-slate-400 text-center">
                  This will notify the customer and send them their 4-digit Ride Start OTP.
                </p>
              </div>
            )}

            {/* ACTION STEP 2: Enter 4-Digit OTP to Start Trip */}
            {activeRide.status === 'DRIVER_ARRIVED' && (
              <div className="bg-slate-800/95 border-2 border-amber-500/60 rounded-xl p-4 space-y-3">
                <div className="flex items-center space-x-2 text-amber-300">
                  <ShieldAlert className="w-5 h-5" />
                  <h4 className="font-bold text-xs uppercase tracking-wider">Verify Customer 4-Digit OTP</h4>
                </div>
                <p className="text-[11px] text-slate-300">
                  Ask customer for the 4-digit security OTP shown on their screen to start this trip.
                </p>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={inputOtp}
                    placeholder="Enter 4-digit OTP"
                    onChange={e => setInputOtp(e.target.value.replace(/\D/g, ''))}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-center text-lg font-mono font-bold tracking-widest text-amber-400 focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={loading || inputOtp.length !== 4}
                    onClick={handleVerifyOtpAndStart}
                    className="bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold px-4 rounded-xl text-xs"
                  >
                    Start Ride
                  </button>
                </div>
                {rydwalaManager.isDemoMode() && (
                  <p className="text-[10px] text-slate-500 text-center font-mono">
                    (Demo mode: 1234 or actual OTP {activeRide.otp})
                  </p>
                )}
              </div>
            )}

            {/* ACTION STEP 3: In Progress & Complete Trip */}
            {['RIDE_STARTED', 'ON_TRIP'].includes(activeRide.status) && (
              <div className="space-y-2.5">
                <div className="p-3 bg-emerald-950/40 border border-emerald-700/50 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                  <span className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-ping"></span>
                    Trip In Progress
                  </span>
                  <button
                    type="button"
                    onClick={handleSimulateGpsMove}
                    className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 flex items-center"
                  >
                    <Compass className="w-3 h-3 mr-1" /> Broadcast GPS
                  </button>
                </div>

                <button
                  type="button"
                  disabled={loading}
                  onClick={handleCompleteRide}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-rose-600/20"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Complete Ride at Destination</span>
                </button>
              </div>
            )}

            {/* ACTION STEP 4: Collect Payment upon Completion */}
            {activeRide.status === 'COMPLETED' && (
              <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Total Collectable Fare</span>
                  <span className="font-mono font-bold text-xl text-white">₹{activeRide.fare}</span>
                </div>

                <div className="p-2.5 bg-slate-900 rounded-lg text-xs flex items-center justify-between">
                  <span className="text-slate-400">Payment Status:</span>
                  <span
                    className={`font-semibold ${
                      activeRide.paymentStatus === 'PAYMENT_SUCCESSFUL'
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {activeRide.paymentStatus}
                  </span>
                </div>

                {activeRide.paymentStatus !== 'PAYMENT_SUCCESSFUL' ? (
                  <button
                    type="button"
                    disabled={loading}
                    onClick={handleCollectCash}
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20"
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>Confirm Cash Received (₹{activeRide.fare})</span>
                  </button>
                ) : (
                  <div className="p-2.5 bg-emerald-950 border border-emerald-700/60 rounded-xl text-center text-xs text-emerald-300 font-medium">
                    ✅ Payment Received & Verified! Driver ready for next ride.
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          /* IDLE WAITING SCREEN */
          <div className="p-6 bg-slate-800/40 border border-dashed border-slate-700 rounded-2xl text-center space-y-3 my-auto">
            <div className={`w-14 h-14 rounded-full mx-auto flex items-center justify-center text-2xl ${
              driver.isOnline ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-500'
            }`}>
              {driver.isOnline ? '🛺' : '💤'}
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-200">
                {driver.isOnline ? 'Waiting for Nearby Ride Requests' : 'You are currently Offline'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {driver.isOnline
                  ? 'Keep app active. Rides booked by customers will pop up here in real-time.'
                  : 'Toggle the switch above to go online and receive rides.'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-400 text-center flex items-center justify-between">
        <span>Driver ID: {driverId}</span>
        <span>WebSocket: Connected</span>
      </div>
    </div>
  );
};

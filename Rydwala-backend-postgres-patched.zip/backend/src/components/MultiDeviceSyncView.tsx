import React, { useState } from 'react';
import { CustomerAppView } from './CustomerAppView.tsx';
import { DriverAppView } from './DriverAppView.tsx';
import { RideData } from '../services/types.ts';
import { Smartphone, Zap, CheckCircle2 } from 'lucide-react';

export const MultiDeviceSyncView: React.FC = () => {
  const [sharedRideId, setSharedRideId] = useState<string | null>(null);
  const [lastEvent, setLastEvent] = useState<string>('Ready for test booking');

  const handleCustomerRideChange = (ride: RideData | null) => {
    if (ride) {
      setSharedRideId(ride.rideId);
      setLastEvent(`Customer booked: ${ride.rideId} (${ride.status})`);
    } else {
      setSharedRideId(null);
    }
  };

  const handleDriverRideChange = (ride: RideData | null) => {
    if (ride) {
      setSharedRideId(ride.rideId);
      setLastEvent(`Driver updated: ${ride.rideId} (${ride.status})`);
    }
  };

  return (
    <div className="space-y-4 max-w-6xl mx-auto">
      {/* Live sync banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-white text-sm">Multi-Device Central Synchronization Simulator</div>
            <div className="text-slate-400">
              Both screens connect to Central Backend (`/api/v1`) & WebSockets (`/ws`) — no localStorage sharing!
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-slate-400">Active Shared Ride:</span>
          <span className="font-mono font-bold text-emerald-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
            {sharedRideId || 'None (Book on Left to Start)'}
          </span>
        </div>
      </div>

      {/* Side-by-side Dual Device View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Device 1: Customer Phone */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs px-2 text-slate-400">
            <span className="flex items-center font-bold text-slate-200">
              <Smartphone className="w-4 h-4 mr-1 text-emerald-400" /> Device A: Customer Mobile App
            </span>
            <span className="font-mono text-emerald-400">User: Aniket More</span>
          </div>
          <CustomerAppView onRideChange={handleCustomerRideChange} externalRideId={sharedRideId} />
        </div>

        {/* Device 2: Driver Partner Phone */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs px-2 text-slate-400">
            <span className="flex items-center font-bold text-slate-200">
              <Smartphone className="w-4 h-4 mr-1 text-amber-400" /> Device B: Driver Partner App
            </span>
            <span className="font-mono text-amber-400">Driver: Sachin Patil (DRV-101)</span>
          </div>
          <DriverAppView onRideChange={handleDriverRideChange} externalRideId={sharedRideId} />
        </div>
      </div>
    </div>
  );
};

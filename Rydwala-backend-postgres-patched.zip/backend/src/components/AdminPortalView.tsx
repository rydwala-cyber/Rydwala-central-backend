import React, { useState, useEffect } from 'react';
import {
  Users,
  Car,
  TrendingUp,
  CreditCard,
  Map,
  Settings,
  ShieldCheck,
  Ban,
  CheckCircle,
  RefreshCw,
  Clock,
  Activity,
  Radio,
  Sliders,
} from 'lucide-react';
import { apiClient } from '../services/apiClient.ts';

export const AdminPortalView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'riders' | 'customers' | 'rides' | 'payments' | 'settings'>('dashboard');
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<any>(null);
  const [riders, setRiders] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [rides, setRides] = useState<any[]>([]);
  const [paymentsData, setPaymentsData] = useState<any>({ payments: [], transactions: [] });
  const [serviceAreas, setServiceAreas] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({
    demoMode: false,
    allowDemoOtp: false,
    platformCommissionPercent: 15,
    surgeMultiplier: 1.0,
    upiMerchantId: 'rydwala@icici',
    upiMerchantName: 'Rydwala Mobility Pvt Ltd',
    autoAssignDrivers: false,
  });

  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadAllAdminData();
  }, []);

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [dashRes, ridersRes, custRes, ridesRes, payRes, areasRes] = await Promise.all([
        apiClient.get('/admin/dashboard'),
        apiClient.get('/admin/riders'),
        apiClient.get('/admin/customers'),
        apiClient.get('/admin/rides'),
        apiClient.get('/admin/payments'),
        apiClient.get('/service-areas'),
      ]);

      if (dashRes.success) {
        setStats(dashRes);
        setSettings(dashRes.settings);
      }
      if (ridersRes.success) setRiders(ridersRes.riders || []);
      if (custRes.success) setCustomers(custRes.customers || []);
      if (ridesRes.success) setRides(ridesRes.rides || []);
      if (payRes.success) setPaymentsData(payRes);
      if (areasRes.success) setServiceAreas(areasRes.areas || []);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRiderStatus = async (driverId: string, status: string) => {
    try {
      const res = await apiClient.patch(`/admin/riders/${driverId}/status`, { status });
      if (res.success) {
        setMessage(`Driver ${driverId} status set to ${status}`);
        loadAllAdminData();
      }
    } catch (err) {
      setMessage((err as Error).message);
    }
  };

  const handleUpdateCustomerStatus = async (customerId: string, status: string) => {
    try {
      const res = await apiClient.patch(`/admin/customers/${customerId}/status`, { status });
      if (res.success) {
        setMessage(`Customer ${customerId} status set to ${status}`);
        loadAllAdminData();
      }
    } catch (err) {
      setMessage((err as Error).message);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiClient.post('/admin/settings', settings);
      if (res.success) {
        setMessage('Settings saved successfully!');
        loadAllAdminData();
      }
    } catch (err) {
      setMessage((err as Error).message);
    }
  };

  const kpis = stats?.kpis || {
    totalCustomers: 0,
    totalRegisteredDrivers: 0,
    activeDrivers: 0,
    onlineDrivers: 0,
    activeRidesCount: 0,
    completedRidesCount: 0,
    totalRevenue: 0,
    platformCommission: 0,
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl text-slate-100 shadow-2xl overflow-hidden w-full max-w-5xl mx-auto flex flex-col min-h-[700px]">
      {/* Admin Navbar */}
      <div className="bg-slate-950 border-b border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xl shadow">
            🛡️
          </div>
          <div>
            <h2 className="font-bold text-base text-white flex items-center gap-2">
              Rydwala Central Admin Console
              <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-700/50 px-2 py-0.5 rounded-full font-mono">
                PostgreSQL Relational Core
              </span>
            </h2>
            <p className="text-xs text-slate-400">Master Operations, Analytics, Fleet & Gateway Controls</p>
          </div>
        </div>

        {/* Global Action Refresh */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={loadAllAdminData}
            disabled={loading}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl text-xs font-medium border border-slate-700 flex items-center space-x-1.5 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Live Data</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 flex space-x-1 overflow-x-auto text-xs">
        {[
          { id: 'dashboard', label: 'Overview & KPIs', icon: TrendingUp },
          { id: 'riders', label: `Riders & Drivers (${riders.length})`, icon: Car },
          { id: 'customers', label: `Customers (${customers.length})`, icon: Users },
          { id: 'rides', label: `All Rides (${rides.length})`, icon: Activity },
          { id: 'payments', label: `Revenue & Payments`, icon: CreditCard },
          { id: 'settings', label: `UPI & App Config`, icon: Settings },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 px-3.5 font-medium border-b-2 flex items-center space-x-2 whitespace-nowrap transition ${
                isActive
                  ? 'border-indigo-500 text-indigo-400 bg-indigo-950/20'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Message notification */}
      {message && (
        <div className="bg-indigo-950 border-b border-indigo-800 px-4 py-2 text-xs text-indigo-200 flex justify-between items-center">
          <span>{message}</span>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Tab Contents */}
      <div className="p-6 flex-1 overflow-y-auto space-y-6">
        {/* DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider block">Total Customers</span>
                <div className="text-2xl font-bold text-white font-mono mt-1">{kpis.totalCustomers}</div>
                <span className="text-[10px] text-emerald-400 mt-1 block">Active Accounts</span>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider block">Registered Drivers</span>
                <div className="text-2xl font-bold text-amber-400 font-mono mt-1">{kpis.totalRegisteredDrivers}</div>
                <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
                  <span>Online: <strong className="text-emerald-400">{kpis.onlineDrivers}</strong></span>
                  <span>Active: {kpis.activeDrivers}</span>
                </div>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider block">Active Rides Live</span>
                <div className="text-2xl font-bold text-indigo-400 font-mono mt-1 flex items-center">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 mr-2 animate-ping"></span>
                  {kpis.activeRidesCount}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">Completed: {kpis.completedRidesCount}</span>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider block">Total Platform GMV</span>
                <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">₹{kpis.totalRevenue}</div>
                <span className="text-[10px] text-indigo-300 mt-1 block">
                  Commission: ₹{kpis.platformCommission} (15%)
                </span>
              </div>
            </div>

            {/* Service Areas & Live WebSocket Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center">
                  <Map className="w-4 h-4 mr-2 text-indigo-400" />
                  Active Service Hubs ({serviceAreas.length})
                </h3>
                <div className="space-y-2">
                  {serviceAreas.map(area => (
                    <div key={area.areaId} className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-200">{area.name}</div>
                        <div className="text-slate-400 text-[11px]">{area.city}, {area.state} • Radius: {area.radiusKm}km</div>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 rounded text-[10px] font-mono">
                        Base: ₹{area.baseFare}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center">
                  <Radio className="w-4 h-4 mr-2 text-emerald-400" />
                  Real-time WebSocket & Architecture
                </h3>
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Connected Sockets:</span>
                    <span className="font-bold text-emerald-400 font-mono">{stats?.wsClients?.total || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Database Engine:</span>
                    <span className="font-bold text-indigo-300">
                      {stats?.isPostgresConnected ? 'PostgreSQL (Active Pool)' : 'Relational Store (Postgres Schema Parity)'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Auto Assign Drivers:</span>
                    <span className="font-mono text-white">{settings.autoAssignDrivers ? 'Enabled' : 'Disabled'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Platform Commission:</span>
                    <span className="font-mono text-emerald-400">{settings.platformCommissionPercent}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* RIDERS TAB */}
        {activeTab === 'riders' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Driver Fleet Management</h3>
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-medium uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3">Driver ID</th>
                    <th className="p-3">Name & Phone</th>
                    <th className="p-3">Vehicle</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Online</th>
                    <th className="p-3">Rating & Rides</th>
                    <th className="p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {riders.map(d => (
                    <tr key={d.driverId} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono font-bold text-amber-400">{d.driverId}</td>
                      <td className="p-3">
                        <div className="font-bold text-white">{d.name}</div>
                        <div className="text-slate-400 font-mono text-[11px]">+91 {d.phone}</div>
                      </td>
                      <td className="p-3">
                        <div className="text-slate-200">{d.vehicleModel}</div>
                        <div className="text-slate-400 font-mono text-[11px]">{d.vehicleNumber} ({d.vehicleType})</div>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          d.status === 'ACTIVE' ? 'bg-emerald-950 text-emerald-400' :
                          d.status === 'PENDING_APPROVAL' ? 'bg-amber-950 text-amber-400' :
                          'bg-red-950 text-red-400'
                        }`}>
                          {d.status}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className={`w-2 h-2 rounded-full inline-block mr-1.5 ${d.isOnline ? 'bg-emerald-400' : 'bg-slate-600'}`}></span>
                        {d.isOnline ? 'Online' : 'Offline'}
                      </td>
                      <td className="p-3">
                        <div>⭐ {d.rating || 5.0}</div>
                        <div className="text-slate-400 text-[10px]">{d.totalRides || 0} rides • ₹{d.totalEarnings || 0}</div>
                      </td>
                      <td className="p-3">
                        <div className="flex space-x-1.5">
                          {d.status !== 'ACTIVE' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateRiderStatus(d.driverId, 'ACTIVE')}
                              className="px-2 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-[10px]"
                            >
                              Approve
                            </button>
                          )}
                          {d.status === 'ACTIVE' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateRiderStatus(d.driverId, 'BLOCKED')}
                              className="px-2 py-1 bg-red-900 hover:bg-red-800 text-white rounded text-[10px]"
                            >
                              Block
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* CUSTOMERS TAB */}
        {activeTab === 'customers' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Customer Base</h3>
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-medium uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3">Customer ID</th>
                    <th className="p-3">Name</th>
                    <th className="p-3">Phone</th>
                    <th className="p-3">Total Rides</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {customers.map(c => (
                    <tr key={c.customerId} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono text-emerald-400">{c.customerId}</td>
                      <td className="p-3 font-bold text-white">{c.name}</td>
                      <td className="p-3 font-mono text-slate-300">+91 {c.phone}</td>
                      <td className="p-3 font-mono">{c.totalRides || 0}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          c.status === 'ACTIVE' ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'
                        }`}>
                          {c.status}
                        </span>
                      </td>
                      <td className="p-3">
                        <button
                          type="button"
                          onClick={() => handleUpdateCustomerStatus(c.customerId, c.status === 'ACTIVE' ? 'BLOCKED' : 'ACTIVE')}
                          className={`px-2.5 py-1 rounded text-[10px] font-medium ${
                            c.status === 'ACTIVE' ? 'bg-red-900 text-white' : 'bg-emerald-700 text-white'
                          }`}
                        >
                          {c.status === 'ACTIVE' ? 'Block' : 'Unblock'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ALL RIDES TAB */}
        {activeTab === 'rides' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Central Shared Rides Log</h3>
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-medium uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3">Ride ID</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Driver</th>
                    <th className="p-3">Route</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">OTP</th>
                    <th className="p-3">Fare & Payment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {rides.map(r => (
                    <tr key={r.rideId} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono font-bold text-indigo-400">{r.rideId}</td>
                      <td className="p-3">
                        <div>{r.customerName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{r.customerPhone}</div>
                      </td>
                      <td className="p-3">
                        {r.driverName ? (
                          <>
                            <div className="text-amber-300">{r.driverName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{r.vehicleNumber}</div>
                          </>
                        ) : (
                          <span className="text-slate-500 italic">Searching...</span>
                        )}
                      </td>
                      <td className="p-3 max-w-[200px] truncate">
                        <div className="truncate text-emerald-400">{r.pickup}</div>
                        <div className="truncate text-rose-400">{r.drop}</div>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] font-mono">
                          {r.status}
                        </span>
                      </td>
                      <td className="p-3 font-mono font-bold text-amber-400">
                        {r.otp} {r.otpVerified && '✓'}
                      </td>
                      <td className="p-3 font-mono">
                        <div className="font-bold text-white">₹{r.fare}</div>
                        <div className="text-[10px] text-slate-400">{r.paymentMethod} • {r.paymentStatus}</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PAYMENTS TAB */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-white">Payment Records & Transaction Ledger</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700">
                <h4 className="font-bold text-xs text-emerald-400 uppercase tracking-wider mb-3">
                  Settled Payments ({paymentsData.payments?.length || 0})
                </h4>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {paymentsData.payments?.map((p: any) => (
                    <div key={p.paymentId} className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-xs flex justify-between items-center">
                      <div>
                        <div className="font-mono font-bold text-slate-200">{p.paymentId}</div>
                        <div className="text-slate-400 text-[10px]">Ride: {p.rideId} • Method: {p.method}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold font-mono text-emerald-400">₹{p.amount}</div>
                        <span className="text-[9px] text-emerald-300 bg-emerald-950 px-1.5 py-0.5 rounded">
                          {p.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700">
                <h4 className="font-bold text-xs text-indigo-400 uppercase tracking-wider mb-3">
                  Revenue Commission Split Ledger
                </h4>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {paymentsData.transactions?.map((t: any) => (
                    <div key={t.transactionId} className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-xs flex justify-between items-center">
                      <div>
                        <div className="font-mono font-bold text-slate-200">{t.transactionId}</div>
                        <div className="text-slate-400 text-[10px]">{t.description}</div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="text-white font-bold">₹{t.amount}</div>
                        <div className="text-[10px] text-emerald-400">Driver: ₹{t.driverEarnings} | Fee: ₹{t.platformFee}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSaveSettings} className="bg-slate-800/60 p-6 rounded-xl border border-slate-700 max-w-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center">
              <Sliders className="w-4 h-4 mr-2 text-indigo-400" />
              Central Gateway & UPI QR Configuration
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">UPI Merchant VPA (Virtual Payment Address)</label>
                <input
                  type="text"
                  value={settings.upiMerchantId}
                  onChange={e => setSettings({ ...settings, upiMerchantId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">UPI Merchant Registered Business Name</label>
                <input
                  type="text"
                  value={settings.upiMerchantName}
                  onChange={e => setSettings({ ...settings, upiMerchantName: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Platform Commission (%)</label>
                  <input
                    type="number"
                    value={settings.platformCommissionPercent}
                    onChange={e => setSettings({ ...settings, platformCommissionPercent: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Surge Multiplier</label>
                  <input
                    type="number"
                    step="0.1"
                    value={settings.surgeMultiplier}
                    onChange={e => setSettings({ ...settings, surgeMultiplier: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 space-y-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoAssignDrivers}
                    onChange={e => setSettings({ ...settings, autoAssignDrivers: e.target.checked })}
                    className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700"
                  />
                  <span className="text-slate-200 font-medium">Auto-assign nearest online driver upon ride booking</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.demoMode}
                    onChange={e => setSettings({ ...settings, demoMode: e.target.checked })}
                    className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700"
                  />
                  <span className="text-slate-200 font-medium">Allow Demo Mode (Accept 1234 demo OTP in testing)</span>
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-5 rounded-xl text-xs shadow-lg shadow-indigo-600/30"
            >
              Save Central Settings
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

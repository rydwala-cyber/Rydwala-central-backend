import React, { useState, useEffect } from 'react';
import {
  Code,
  Radio,
  Database,
  FileText,
  Play,
  Terminal,
  Layers,
  CheckCircle2,
  Copy,
  Check,
  Server,
  Globe,
  Key,
} from 'lucide-react';
import { socketClient } from '../services/apiClient.ts';

export const ApiExplorerView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'endpoints' | 'websocket' | 'schema' | 'architecture' | 'env'>('endpoints');
  const [selectedEndpointIndex, setSelectedEndpointIndex] = useState(0);
  const [requestBody, setRequestBody] = useState('');
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [wsLogs, setWsLogs] = useState<any[]>([]);
  const [copied, setCopied] = useState(false);

  // Pre-configured API catalog
  const endpoints = [
    {
      method: 'GET',
      path: '/api/v1/system/health',
      name: 'System Health & Engine Status',
      category: 'System',
      description: 'Checks Central Backend health, connected WebSocket clients, and DB status.',
      body: '',
    },
    {
      method: 'POST',
      path: '/api/v1/auth/customer/register',
      name: 'Register Customer',
      category: 'Auth',
      description: 'Creates a new unique customer ID and returns JWT token.',
      body: JSON.stringify({ name: 'Rahul Shinde', phone: '9822998877', email: 'rahul@gmail.com' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/auth/customer/login',
      name: 'Customer Login',
      category: 'Auth',
      description: 'Customer login via phone number with JWT token issue.',
      body: JSON.stringify({ phone: '9890123456' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/auth/driver/register',
      name: 'Register Driver',
      category: 'Auth',
      description: 'Registers driver partner with vehicle type, model and number plate.',
      body: JSON.stringify({
        name: 'Vikas Gaikwad',
        phone: '9922114433',
        vehicleType: 'SEDAN',
        vehicleModel: 'Hyundai Aura',
        vehicleNumber: 'MH 12 XY 9988',
        licenseNumber: 'MH12-2020-0012345',
      }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/auth/driver/login',
      name: 'Driver Login',
      category: 'Auth',
      description: 'Driver login via Driver ID or Phone.',
      body: JSON.stringify({ driverId: 'DRV-101' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/rides',
      name: 'Create Shared Ride Request',
      category: 'Rides',
      description: 'Creates a ride request, calculates distance & fare, generates unique 4-digit OTP, and broadcasts to available drivers.',
      body: JSON.stringify({
        customerId: 'CUST-001',
        pickup: 'Shivajinagar Station, Pune',
        drop: 'Viman Nagar IT Hub, Pune',
        pickupLat: 18.5314,
        pickupLng: 73.8446,
        dropLat: 18.5679,
        dropLng: 73.9143,
        rideOption: 'AUTO',
        paymentMethod: 'CASH',
      }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/rides/RIDE-DEMO/accept',
      name: 'Driver Accept Ride',
      category: 'Rides',
      description: 'Driver accepts a pending ride request.',
      body: JSON.stringify({ driverId: 'DRV-101' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/rides/RIDE-DEMO/arrived',
      name: 'Driver Arrived at Pickup',
      category: 'Rides',
      description: 'Marks driver arrival and pushes OTP event to Customer App.',
      body: JSON.stringify({ driverId: 'DRV-101' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/rides/RIDE-DEMO/verify-otp',
      name: 'Server-side OTP Verification',
      category: 'Rides',
      description: 'Driver submits customer OTP. Valid OTP starts ride.',
      body: JSON.stringify({ driverId: 'DRV-101', otp: '1234' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/rides/RIDE-DEMO/complete',
      name: 'Complete Ride',
      category: 'Rides',
      description: 'Completes ride, calculates driver earnings, updates customer count.',
      body: JSON.stringify({ driverId: 'DRV-101' }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/drivers/DRV-101/location',
      name: 'Broadcast Driver GPS Location',
      category: 'Drivers',
      description: 'Updates live GPS coordinates and streams to active customer.',
      body: JSON.stringify({ lat: 18.5320, lng: 73.8450, heading: 90, speed: 28 }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/payments/cash',
      name: 'Confirm Cash Payment',
      category: 'Payments',
      description: 'Driver confirms cash collection, sets PAYMENT_SUCCESSFUL, logs commission.',
      body: JSON.stringify({ rideId: 'RIDE-DEMO', driverId: 'DRV-101', amount: 85 }, null, 2),
    },
    {
      method: 'POST',
      path: '/api/v1/payments/upi/webhook',
      name: 'UPI Gateway Webhook Verification',
      category: 'Payments',
      description: 'Verifies external gateway transaction before marking payment successful.',
      body: JSON.stringify({
        rideId: 'RIDE-DEMO',
        transactionRef: 'UPI-TXN-998811',
        amount: 85,
        status: 'SUCCESS',
      }, null, 2),
    },
    {
      method: 'GET',
      path: '/api/v1/admin/dashboard',
      name: 'Admin Dashboard KPIs',
      category: 'Admin',
      description: 'Returns total customers, registered riders, online riders, GMV, earnings.',
      body: '',
    },
    {
      method: 'GET',
      path: '/api/v1/service-areas',
      name: 'List Service Areas',
      category: 'Service Areas',
      description: 'Returns active operation cities & pricing structures (Pune, Mumbai, Nashik, etc.).',
      body: '',
    },
  ];

  useEffect(() => {
    setRequestBody(endpoints[selectedEndpointIndex].body);
  }, [selectedEndpointIndex]);

  // Listen to all WebSocket events for live streaming feed
  useEffect(() => {
    socketClient.connect('EXPLORER-ADMIN', 'ADMIN');
    const unsub = socketClient.on('*', (rawMsg: any) => {
      setWsLogs(prev => [
        {
          id: Date.now(),
          time: new Date().toLocaleTimeString(),
          event: rawMsg.event,
          payload: rawMsg.payload,
        },
        ...prev.slice(0, 30),
      ]);
    });

    return () => {
      unsub();
    };
  }, []);

  const handleExecuteApi = async () => {
    const ep = endpoints[selectedEndpointIndex];
    setLoading(true);
    setApiResponse(null);

    try {
      let url = ep.path;
      // In dynamic calls replace RIDE-DEMO with a real one if available
      const options: RequestInit = {
        method: ep.method,
        headers: { 'Content-Type': 'application/json' },
      };

      if (ep.method !== 'GET' && requestBody) {
        options.body = requestBody;
      }

      const res = await fetch(url, options);
      const data = await res.json();
      setApiResponse({
        status: res.status,
        statusText: res.statusText,
        data,
      });
    } catch (err) {
      setApiResponse({
        status: 500,
        error: (err as Error).message,
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl text-slate-100 shadow-2xl overflow-hidden w-full max-w-5xl mx-auto flex flex-col min-h-[700px]">
      {/* Header */}
      <div className="bg-slate-950 border-b border-slate-800 p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-xl shadow">
            ⚡
          </div>
          <div>
            <h2 className="font-bold text-base text-white flex items-center gap-2">
              Rydwala Central Backend Engine Explorer
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700/50 px-2 py-0.5 rounded-full font-mono">
                Port 3000 / API v1
              </span>
            </h2>
            <p className="text-xs text-slate-400">Interactive REST Testing, WebSocket Streams, & PostgreSQL Schema</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 flex space-x-2 text-xs">
        {[
          { id: 'endpoints', label: 'REST API Tester (25+ Endpoints)', icon: Code },
          { id: 'websocket', label: `Live WebSocket Feed (${wsLogs.length} events)`, icon: Radio },
          { id: 'schema', label: 'PostgreSQL Relational Schema', icon: Database },
          { id: 'architecture', label: 'Architecture & Service Layer', icon: Layers },
          { id: 'env', label: 'Environment & Config Guide', icon: Key },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 px-3 font-medium border-b-2 flex items-center space-x-2 transition ${
                isActive
                  ? 'border-teal-500 text-teal-400 bg-teal-950/20'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Body */}
      <div className="p-5 flex-1 overflow-y-auto">
        {/* ENDPOINTS TESTER */}
        {activeTab === 'endpoints' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Endpoints Sidebar */}
            <div className="md:col-span-4 bg-slate-950/80 rounded-xl p-2 border border-slate-800 max-h-[580px] overflow-y-auto space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1 block">API Modules</span>
              {endpoints.map((ep, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedEndpointIndex(idx)}
                  className={`w-full text-left p-2 rounded-lg text-xs transition flex items-center justify-between ${
                    selectedEndpointIndex === idx
                      ? 'bg-teal-900/40 border border-teal-500 text-white'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="truncate">
                    <div className="font-semibold truncate">{ep.name}</div>
                    <div className="font-mono text-[10px] text-slate-400 truncate">{ep.path}</div>
                  </div>
                  <span
                    className={`ml-1 text-[9px] font-bold font-mono px-1.5 py-0.5 rounded ${
                      ep.method === 'GET'
                        ? 'bg-emerald-950 text-emerald-400'
                        : ep.method === 'POST'
                        ? 'bg-indigo-950 text-indigo-400'
                        : 'bg-amber-950 text-amber-400'
                    }`}
                  >
                    {ep.method}
                  </span>
                </button>
              ))}
            </div>

            {/* Request / Response Panel */}
            <div className="md:col-span-8 space-y-4">
              {/* Endpoint Details */}
              <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-white">
                    {endpoints[selectedEndpointIndex].name}
                  </span>
                  <span className="text-xs text-teal-400 font-mono">
                    {endpoints[selectedEndpointIndex].category}
                  </span>
                </div>
                <div className="flex items-center space-x-2 font-mono text-xs bg-slate-900 p-2 rounded-lg border border-slate-800">
                  <span className="font-bold text-teal-400">{endpoints[selectedEndpointIndex].method}</span>
                  <span className="text-slate-200">{endpoints[selectedEndpointIndex].path}</span>
                </div>
                <p className="text-xs text-slate-300">{endpoints[selectedEndpointIndex].description}</p>
              </div>

              {/* Request Payload Editor */}
              {endpoints[selectedEndpointIndex].method !== 'GET' && (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300 block">JSON Request Body</label>
                  <textarea
                    rows={6}
                    value={requestBody}
                    onChange={e => setRequestBody(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 font-mono text-xs text-emerald-400 focus:outline-none focus:border-teal-500"
                  />
                </div>
              )}

              {/* Execute Button */}
              <button
                type="button"
                disabled={loading}
                onClick={handleExecuteApi}
                className="w-full bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-teal-500/20"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{loading ? 'Executing Central API...' : 'Execute Request'}</span>
              </button>

              {/* Response Viewer */}
              {apiResponse && (
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-mono">
                      HTTP Status: <strong className="text-emerald-400">{apiResponse.status} {apiResponse.statusText}</strong>
                    </span>
                    <button
                      onClick={() => copyToClipboard(JSON.stringify(apiResponse.data, null, 2))}
                      className="text-slate-400 hover:text-white flex items-center text-[10px]"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                      {copied ? 'Copied' : 'Copy JSON'}
                    </button>
                  </div>
                  <pre className="text-xs font-mono text-slate-200 overflow-x-auto max-h-[220px] p-2 bg-slate-900 rounded-lg">
                    {JSON.stringify(apiResponse.data || apiResponse, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}

        {/* WEBSOCKET LIVE STREAM */}
        {activeTab === 'websocket' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="font-mono text-slate-200">Gateway URL: ws://localhost:3000/ws</span>
              </div>
              <button
                type="button"
                onClick={() => setWsLogs([])}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded text-[11px]"
              >
                Clear Stream
              </button>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {wsLogs.length === 0 ? (
                <div className="p-8 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl">
                  <Terminal className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                  <p className="text-xs">Listening for WebSocket broadcasts...</p>
                  <p className="text-[10px]">Create a ride or update driver status to see live frames here.</p>
                </div>
              ) : (
                wsLogs.map(log => (
                  <div key={log.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono space-y-1">
                    <div className="flex items-center justify-between text-slate-400 text-[10px]">
                      <span className="text-teal-400 font-bold">{log.event}</span>
                      <span>{log.time}</span>
                    </div>
                    <pre className="text-slate-300 text-[11px] overflow-x-auto">
                      {JSON.stringify(log.payload, null, 2)}
                    </pre>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* DATABASE SCHEMA */}
        {activeTab === 'schema' && (
          <div className="space-y-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-xs space-y-2">
              <h3 className="font-bold text-sm text-white flex items-center">
                <Database className="w-4 h-4 mr-2 text-teal-400" />
                PostgreSQL Relational Tables & Integrity Constraints
              </h3>
              <p className="text-slate-300">
                Primary and foreign keys establish full relational integrity between Customers, Drivers, Shared Rides, Payments, and Transactions.
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto max-h-[480px]">
              <pre>{`-- Rydwala Database Schema Summary
TABLE customers (
  customer_id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(128) UNIQUE,
  password_hash VARCHAR(255),
  status VARCHAR(32) DEFAULT 'ACTIVE',
  rating NUMERIC(3,2) DEFAULT 5.00,
  total_rides INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

TABLE drivers (
  driver_id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  vehicle_type VARCHAR(32) NOT NULL,
  vehicle_model VARCHAR(128) NOT NULL,
  vehicle_number VARCHAR(32) NOT NULL,
  status VARCHAR(32) DEFAULT 'ACTIVE',
  is_online BOOLEAN DEFAULT FALSE,
  is_busy BOOLEAN DEFAULT FALSE,
  rating NUMERIC(3,2) DEFAULT 4.90,
  total_rides INTEGER DEFAULT 0,
  total_earnings NUMERIC(12,2) DEFAULT 0.00,
  current_lat NUMERIC(10,7),
  current_lng NUMERIC(10,7)
);

TABLE rides (
  ride_id VARCHAR(64) PRIMARY KEY,
  customer_id VARCHAR(64) REFERENCES customers(customer_id) ON DELETE CASCADE,
  driver_id VARCHAR(64) REFERENCES drivers(driver_id) ON DELETE SET NULL,
  customer_name VARCHAR(128) NOT NULL,
  customer_phone VARCHAR(20) NOT NULL,
  driver_name VARCHAR(128),
  driver_phone VARCHAR(20),
  vehicle_model VARCHAR(128),
  vehicle_number VARCHAR(32),
  vehicle_type VARCHAR(32) NOT NULL,
  pickup TEXT NOT NULL,
  drop_location TEXT NOT NULL,
  pickup_lat NUMERIC(10,7) NOT NULL,
  pickup_lng NUMERIC(10,7) NOT NULL,
  drop_lat NUMERIC(10,7) NOT NULL,
  drop_lng NUMERIC(10,7) NOT NULL,
  distance_km NUMERIC(6,2) NOT NULL,
  fare NUMERIC(10,2) NOT NULL,
  otp VARCHAR(10) NOT NULL,
  otp_verified BOOLEAN DEFAULT FALSE,
  status VARCHAR(32) DEFAULT 'SEARCHING',
  payment_method VARCHAR(32) DEFAULT 'CASH',
  payment_status VARCHAR(32) DEFAULT 'PAYMENT_PENDING',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  arrived_at TIMESTAMP WITH TIME ZONE,
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE
);

TABLE payments (
  payment_id VARCHAR(64) PRIMARY KEY,
  ride_id VARCHAR(64) REFERENCES rides(ride_id) ON DELETE CASCADE,
  customer_id VARCHAR(64) REFERENCES customers(customer_id),
  driver_id VARCHAR(64) REFERENCES drivers(driver_id),
  amount NUMERIC(10,2) NOT NULL,
  method VARCHAR(32) NOT NULL,
  status VARCHAR(32) DEFAULT 'PAYMENT_PENDING',
  transaction_ref VARCHAR(128),
  collected_by_driver BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);`}</pre>
            </div>
          </div>
        )}

        {/* ARCHITECTURE */}
        {activeTab === 'architecture' && (
          <div className="space-y-4 text-xs text-slate-300">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-3">
              <h3 className="font-bold text-sm text-white">Rydwala Central Backend Architecture</h3>
              <p>
                The Rydwala architecture decouples device local storage by centralizing all state in a production REST + WebSocket backend.
              </p>
              <div className="bg-slate-950 p-4 rounded-lg font-mono text-teal-400 text-center leading-relaxed border border-slate-800">
                Customer App ➔ Central Backend (/api/v1) ➔ PostgreSQL & Relational Core ➔ WebSockets (/ws) ➔ Driver App
                <br />
                <span className="text-amber-400 text-xs">▲ Syncs simultaneously across all mobile & web client devices ▲</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 space-y-2">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider">Independent Service Layer</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>AuthService:</strong> JWT + Bcrypt credential security</li>
                  <li><strong>CustomerService:</strong> Profiles, ride history, status moderation</li>
                  <li><strong>DriverService:</strong> Fleets, online toggles, earnings records</li>
                  <li><strong>RideService:</strong> State machine, server-side 4-digit OTP, dispatch</li>
                  <li><strong>FareService:</strong> Haversine geo-distance, vehicle tier rates</li>
                  <li><strong>LocationService:</strong> GPS tracking, nearby driver spatial search</li>
                  <li><strong>PaymentService:</strong> Cash validation, UPI gateway webhooks</li>
                  <li><strong>AdminService:</strong> Real-time KPIs, driver approvals, app settings</li>
                  <li><strong>ServiceAreaService:</strong> Regional boundaries, dynamic hub pricing</li>
                </ul>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 space-y-2">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider">Ride State Transitions</h4>
                <ol className="list-decimal list-inside space-y-1 text-slate-300">
                  <li><code>SEARCHING:</code> Ride request created</li>
                  <li><code>DRIVER_ASSIGNED:</code> Driver accepts request</li>
                  <li><code>DRIVER_ARRIVING:</code> In transit to pickup</li>
                  <li><code>DRIVER_ARRIVED:</code> At pickup (Customer gets 4-digit OTP)</li>
                  <li><code>RIDE_STARTED:</code> Driver verifies OTP on server</li>
                  <li><code>ON_TRIP:</code> Live GPS broadcast</li>
                  <li><code>COMPLETED:</code> Driver reaches destination</li>
                  <li><code>PAYMENT_SUCCESSFUL:</code> Cash confirmed / UPI verified</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* ENV */}
        {activeTab === 'env' && (
          <div className="space-y-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-xs">
              <h3 className="font-bold text-sm text-white mb-2">Production Environment Configuration (.env)</h3>
              <p className="text-slate-300 mb-3">
                Configure these environment variables for production PostgreSQL database, secure JWT secrets, and UPI webhook keys:
              </p>
              <pre className="bg-slate-950 p-3.5 rounded-lg font-mono text-emerald-400 text-xs overflow-x-auto">
{`PORT=3000
NODE_ENV=production
DEMO_MODE=false

JWT_SECRET=your_super_secret_jwt_key_2026
JWT_EXPIRES_IN=7d

DATABASE_URL=postgresql://username:password@your-postgres-host:5432/rydwala_db
PGHOST=your-postgres-host
PGUSER=username
PGPASSWORD=password
PGDATABASE=rydwala_db
PGPORT=5432

UPI_MERCHANT_ID=rydwala@icici
UPI_MERCHANT_NAME=Rydwala Mobility Pvt Ltd
PAYMENT_WEBHOOK_SECRET=whsec_prod_live_9981`}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

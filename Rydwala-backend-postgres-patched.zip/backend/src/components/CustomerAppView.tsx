import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Navigation,
  Car,
  Clock,
  ShieldCheck,
  Phone,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Banknote,
  RefreshCw,
  Zap,
} from 'lucide-react';
import { rydwalaService, rydwalaManager } from '../services/rydwalaService.ts';
import { socketClient } from '../services/apiClient.ts';
import { RideData, RideOptionType } from '../services/types.ts';

export const CustomerAppView: React.FC<{
  onRideChange?: (ride: RideData | null) => void;
  externalRideId?: string | null;
}> = ({ onRideChange, externalRideId }) => {
  const [customerPhone, setCustomerPhone] = useState('9890123456');
  const [customerName, setCustomerName] = useState('Aniket More');
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [customerId, setCustomerId] = useState('CUST-001');

  // Booking details
  const [pickup, setPickup] = useState('FC Road, Deccan Gymkhana, Pune');
  const [drop, setDrop] = useState('Magarpatta Cybercity, Hadapsar, Pune');
  const [pickupCoords, setPickupCoords] = useState({ lat: 18.5204, lng: 73.8567 });
  const [dropCoords, setDropCoords] = useState({ lat: 18.5135, lng: 73.9272 });
  const [selectedOption, setSelectedOption] = useState<RideOptionType>('AUTO');
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'UPI'>('CASH');

  // Active ride state
  const [activeRide, setActiveRide] = useState<RideData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [driverLocation, setDriverLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [upiIntent, setUpiIntent] = useState<any>(null);
  const [isVerifyingUpi, setIsVerifyingUpi] = useState(false);

  // Sync external ride ID if changed
  useEffect(() => {
    if (externalRideId && (!activeRide || activeRide.rideId !== externalRideId)) {
      rydwalaService.getRide(externalRideId).then(r => {
        setActiveRide(r);
        onRideChange?.(r);
      }).catch(() => {});
    }
  }, [externalRideId]);

  // Connect socket and listen to real-time events
  useEffect(() => {
    socketClient.connect(customerId, 'CUSTOMER');
    socketClient.identify(customerId, 'CUSTOMER', activeRide?.rideId);

    const unsubAssigned = socketClient.on('DRIVER_ASSIGNED', (payload: any) => {
      console.log('Customer WS: DRIVER_ASSIGNED', payload);
      refreshRide();
    });

    const unsubArriving = socketClient.on('DRIVER_ARRIVING', () => {
      refreshRide();
    });

    const unsubArrived = socketClient.on('DRIVER_ARRIVED', (payload: any) => {
      console.log('Customer WS: DRIVER_ARRIVED', payload);
      refreshRide();
    });

    const unsubStarted = socketClient.on('RIDE_STARTED', () => {
      refreshRide();
    });

    const unsubCompleted = socketClient.on('COMPLETED', () => {
      refreshRide();
    });

    const unsubPayment = socketClient.on('PAYMENT_SUCCESSFUL', () => {
      refreshRide();
    });

    const unsubLoc = socketClient.on('DRIVER_LOCATION_UPDATE', (payload: any) => {
      if (payload.location) {
        setDriverLocation({ lat: payload.location.lat, lng: payload.location.lng });
      }
    });

    return () => {
      unsubAssigned();
      unsubArriving();
      unsubArrived();
      unsubStarted();
      unsubCompleted();
      unsubPayment();
      unsubLoc();
    };
  }, [customerId, activeRide?.rideId]);

  const refreshRide = async () => {
    if (activeRide?.rideId) {
      try {
        const updated = await rydwalaService.getRide(activeRide.rideId);
        setActiveRide(updated);
        onRideChange?.(updated);
      } catch (e) {
        console.error('Refresh ride error:', e);
      }
    }
  };

  const handleBookRide = async () => {
    setLoading(true);
    setError(null);
    try {
      const ride = await rydwalaService.createRide({
        customerId,
        pickup,
        drop,
        pickupLat: pickupCoords.lat,
        pickupLng: pickupCoords.lng,
        dropLat: dropCoords.lat,
        dropLng: dropCoords.lng,
        rideOption: selectedOption,
        paymentMethod,
      });

      setActiveRide(ride);
      onRideChange?.(ride);
      socketClient.subscribeRide(ride.rideId);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelRide = async () => {
    if (!activeRide) return;
    setLoading(true);
    try {
      const cancelled = await rydwalaService.cancelRide(activeRide.rideId, 'CUSTOMER', 'Rider cancelled booking');
      setActiveRide(cancelled);
      onRideChange?.(cancelled);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleFetchUpi = async () => {
    if (!activeRide) return;
    try {
      const intent = await rydwalaService.getUpiIntent(activeRide.rideId);
      setUpiIntent(intent);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const handleSimulateUpiPayment = async () => {
    if (!activeRide) return;
    setIsVerifyingUpi(true);
    try {
      await rydwalaService.simulateUpiWebhook(
        activeRide.rideId,
        activeRide.fare,
        `UPI-REF-${Date.now().toString().slice(-6)}`
      );
      await refreshRide();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsVerifyingUpi(false);
    }
  };

  const rideOptions = [
    { type: 'BIKE', name: 'Rydwala Bike', time: '2 mins', price: 45, icon: '🏍️' },
    { type: 'AUTO', name: 'Rydwala Auto', time: '3 mins', price: 85, icon: '🛺' },
    { type: 'MINI', name: 'Ryd Mini', time: '5 mins', price: 140, icon: '🚗' },
    { type: 'SEDAN', name: 'Ryd Prime Sedan', time: '6 mins', price: 195, icon: '🚘' },
  ];

  return (
    <div className="bg-slate-900 text-slate-100 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden max-w-md w-full mx-auto flex flex-col min-h-[680px]">
      {/* App Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 p-4 text-white flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2">
          <div className="w-9 h-9 rounded-xl bg-white text-emerald-700 flex items-center justify-center font-black text-xl shadow">
            R
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight leading-none">Rydwala Customer</h1>
            <p className="text-xs text-emerald-100 opacity-90">Central Backend Connected</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-900/60 text-emerald-200 border border-emerald-400/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
            Live API
          </span>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-4 overflow-y-auto">
        {error && (
          <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-red-200 text-xs flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {!activeRide || activeRide.status === 'CANCELLED' ? (
          /* BOOKING SCREEN */
          <div className="space-y-4">
            {/* Customer Badge */}
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center">
                  AM
                </div>
                <div>
                  <div className="font-semibold text-slate-200">{customerName}</div>
                  <div className="text-slate-400 font-mono text-[11px]">+91 {customerPhone}</div>
                </div>
              </div>
              <span className="text-[10px] bg-slate-700 text-emerald-400 px-2 py-0.5 rounded font-mono">
                ID: {customerId}
              </span>
            </div>

            {/* Locations Card */}
            <div className="bg-slate-800/90 rounded-xl p-3 border border-slate-700 space-y-3">
              <div className="flex items-start space-x-2">
                <div className="flex flex-col items-center mt-1">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-emerald-500/30"></div>
                  <div className="w-0.5 h-7 bg-slate-600 my-0.5"></div>
                  <div className="w-3 h-3 rounded-full bg-rose-500 ring-2 ring-rose-500/30"></div>
                </div>
                <div className="flex-1 space-y-2">
                  <div>
                    <label className="text-[10px] font-medium text-slate-400 uppercase tracking-wider block">Pickup</label>
                    <input
                      type="text"
                      value={pickup}
                      onChange={e => setPickup(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-slate-400 uppercase tracking-wider block">Destination</label>
                    <input
                      type="text"
                      value={drop}
                      onChange={e => setDrop(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Ride Category Options */}
            <div>
              <label className="text-xs font-semibold text-slate-300 mb-2 block">Choose Ride Category</label>
              <div className="grid grid-cols-2 gap-2">
                {rideOptions.map(opt => {
                  const isSelected = selectedOption === opt.type;
                  return (
                    <button
                      key={opt.type}
                      type="button"
                      onClick={() => setSelectedOption(opt.type as RideOptionType)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 ring-1 ring-emerald-500'
                          : 'bg-slate-800/60 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-xl">{opt.icon}</span>
                        <span className="font-bold text-sm text-emerald-400 font-mono">₹{opt.price}</span>
                      </div>
                      <div className="mt-1 font-medium text-xs text-slate-200">{opt.name}</div>
                      <div className="text-[10px] text-slate-400 flex items-center mt-0.5">
                        <Clock className="w-2.5 h-2.5 mr-1" /> {opt.time} away
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="bg-slate-800/50 p-2.5 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center">
                <Banknote className="w-3.5 h-3.5 mr-1.5 text-slate-300" /> Payment:
              </span>
              <div className="flex space-x-1.5">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('CASH')}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                    paymentMethod === 'CASH' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  Cash
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('UPI')}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                    paymentMethod === 'UPI' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  UPI QR
                </button>
              </div>
            </div>

            {/* Book Now Button */}
            <button
              type="button"
              disabled={loading}
              onClick={handleBookRide}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition duration-200 flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 active:scale-[0.99] disabled:opacity-50"
            >
              {loading ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-current" />
                  <span>Request Rydwala Now</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* ACTIVE RIDE SCREEN */
          <div className="space-y-4">
            {/* Status Header Badge */}
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Ride Status</span>
                <div className="font-bold text-sm text-emerald-400 flex items-center mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-ping"></span>
                  {activeRide.status.replace(/_/g, ' ')}
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400">Fare</span>
                <div className="font-mono font-bold text-lg text-white">₹{activeRide.fare}</div>
              </div>
            </div>

            {/* OTP CARD - Prominent Display for Security */}
            <div className="bg-gradient-to-br from-amber-500/20 via-slate-800 to-slate-800 border-2 border-amber-500/50 rounded-2xl p-4 text-center relative overflow-hidden shadow-lg">
              <div className="text-[11px] font-semibold tracking-wider uppercase text-amber-300 mb-1 flex items-center justify-center space-x-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Rydwala Security Start OTP</span>
              </div>
              <div className="text-4xl font-mono font-black text-amber-400 tracking-widest my-1 selection:bg-amber-400 selection:text-black">
                {activeRide.otp}
              </div>
              <p className="text-[11px] text-slate-300">
                {activeRide.otpVerified
                  ? '✅ OTP Verified by Driver. Ride in progress.'
                  : 'Share this 4-digit OTP with your driver when vehicle arrives.'}
              </p>
            </div>

            {/* Driver Details Card (When Assigned) */}
            {activeRide.driverName ? (
              <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-600/30 text-emerald-400 font-bold flex items-center justify-center border border-emerald-500/40">
                      🚗
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-100">{activeRide.driverName}</h4>
                      <p className="text-xs text-slate-400 font-mono">
                        {activeRide.vehicleModel} • <span className="text-emerald-400 font-semibold">{activeRide.vehicleNumber}</span>
                      </p>
                    </div>
                  </div>
                  <a
                    href={`tel:${activeRide.driverPhone}`}
                    className="w-9 h-9 rounded-full bg-emerald-600/20 text-emerald-400 flex items-center justify-center hover:bg-emerald-600/30 border border-emerald-500/30"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                </div>

                {driverLocation && (
                  <div className="p-2 bg-slate-900/80 rounded-lg text-[11px] text-slate-300 flex items-center justify-between border border-slate-800">
                    <span className="flex items-center text-emerald-400">
                      <Navigation className="w-3 h-3 mr-1 animate-pulse" /> Driver GPS Live
                    </span>
                    <span className="font-mono text-slate-400">
                      {driverLocation.lat.toFixed(4)}, {driverLocation.lng.toFixed(4)}
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 bg-slate-800/60 border border-dashed border-slate-700 rounded-xl text-center space-y-2">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto text-emerald-400" />
                <p className="text-xs text-slate-300 font-medium">Finding nearby Rydwala drivers...</p>
                <p className="text-[10px] text-slate-500">Central Backend broadcasting to online riders</p>
              </div>
            )}

            {/* Ride Route Summary */}
            <div className="bg-slate-800/40 rounded-xl p-3 border border-slate-700/60 space-y-2 text-xs">
              <div className="flex items-start space-x-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-slate-300 truncate"><strong className="text-slate-400">Pickup:</strong> {activeRide.pickup}</span>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                <span className="text-slate-300 truncate"><strong className="text-slate-400">Drop:</strong> {activeRide.drop}</span>
              </div>
            </div>

            {/* Completed Ride & Payment Card */}
            {activeRide.status === 'COMPLETED' && (
              <div className="bg-emerald-950/40 border border-emerald-600/50 rounded-xl p-4 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <div>
                  <h3 className="font-bold text-sm text-emerald-300">Ride Completed Successfully!</h3>
                  <p className="text-xs text-slate-300 mt-1">Total Fare: ₹{activeRide.fare}</p>
                </div>

                <div className="p-2.5 bg-slate-900 rounded-lg text-xs flex items-center justify-between">
                  <span className="text-slate-400">Payment Status:</span>
                  <span
                    className={`font-semibold ${
                      activeRide.paymentStatus === 'PAYMENT_SUCCESSFUL'
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {activeRide.paymentStatus}
                  </span>
                </div>

                {activeRide.paymentStatus !== 'PAYMENT_SUCCESSFUL' && (
                  <div className="space-y-2 pt-2">
                    <button
                      type="button"
                      onClick={handleFetchUpi}
                      className="w-full bg-teal-600 hover:bg-teal-500 text-white font-medium py-2 rounded-lg text-xs flex items-center justify-center space-x-1"
                    >
                      <QrCode className="w-4 h-4 mr-1" />
                      <span>Show Rydwala UPI QR</span>
                    </button>

                    {upiIntent && (
                      <div className="p-3 bg-slate-900 rounded-xl border border-slate-700 space-y-2">
                        <div className="w-28 h-28 bg-white p-2 rounded-lg mx-auto flex items-center justify-center text-slate-900 font-mono text-[9px] text-center">
                          [Rydwala UPI QR]
                          <br />
                          {upiIntent.upiId}
                          <br />₹{upiIntent.amount}
                        </div>
                        <button
                          type="button"
                          disabled={isVerifyingUpi}
                          onClick={handleSimulateUpiPayment}
                          className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-1.5 rounded text-xs"
                        >
                          {isVerifyingUpi ? 'Verifying Gateway Webhook...' : 'Simulate UPI Gateway Webhook Payment'}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Actions */}
            <div className="flex space-x-2 pt-2">
              <button
                type="button"
                onClick={refreshRide}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2.5 rounded-xl text-xs font-medium border border-slate-700 flex items-center justify-center space-x-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sync Backend</span>
              </button>

              {activeRide.status !== 'COMPLETED' && (
                <button
                  type="button"
                  onClick={handleCancelRide}
                  className="px-4 bg-red-900/40 hover:bg-red-900/60 text-red-300 py-2.5 rounded-xl text-xs font-medium border border-red-800/60"
                >
                  Cancel
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-400 text-center flex items-center justify-between">
        <span>Ride ID: {activeRide?.rideId || 'None'}</span>
        <span>Mode: {rydwalaManager.isDemoMode() ? 'Demo Mode' : 'Central Backend (Live)'}</span>
      </div>
    </div>
  );
};
